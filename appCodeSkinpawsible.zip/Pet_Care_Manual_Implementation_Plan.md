# Pet Care Manual Implementation Plan

This plan outlines the architecture and content strategy for the Pet Care Manual section. Instead of creating six separate activities, we will adopt a scalable dynamic approach.

## Proposed Architecture: Single Detail Activity

To avoid redundant code and layout files, we will create one `ActivityManualDetail` that dynamically loads content based on which topic was clicked from the `ActivityPetCareManual` grid.

1.  **Data Structure**: Create a data class or JSON structure to hold the rich content (headers, paragraphs, images).
2.  **Intent Passing**: When a user clicks a card in `ActivityPetCareManual`, we launch `ActivityManualDetail` and pass a category identifier (e.g., `EXTRA_TOPIC_ID = "skin_care_basics"`).
3.  **UI Components**: `ActivityManualDetail` will contain a ScrollView or a RecyclerView with different view types to beautifully render:
    *   Cover Image (Header)
    *   Title and Subtitle
    *   Section Headers
    *   Paragraph text
    *   Bullet points for tips or checklists.
    *   **Medical Disclaimer Footer**: A persistent banner or footer on the screens explicitly stating: *"Content is sourced from the Merck Veterinary Manual for educational purposes. However, it is not a substitute for professional veterinary advice, diagnosis, or treatment. Always consult your vet."*

## Content Outline per Category

> **Official Data Source:**  
> To ensure all information provided is medically accurate, reliable, and trustworthy, the content for each of these categories will be heavily sourced from and cross-referenced with the **Merck Veterinary Manual**.

### 1. Skin Care Basics
**Goal:** Educate owners on foundational routines for healthy pet skin.
*   **Understanding Pet Skin:** The difference between dog, cat, and human skin (e.g., pH balance).
*   **Daily Routine:** Quick checks you should perform daily (looking for lumps, bumps, redness).
*   **Brushing & Coat Checking:** Why regular brushing distributes natural oils and removes dead hair.
*   **When to be Concerned:** A quick checklist of abnormal signs (excessive scratching, fur loss, flakiness).

### 2. Common Skin Diseases
**Goal:** Serve as a quick reference to identify potential issues before visiting a vet.
*   **Flea Allergy Dermatitis (FAD):** Symptoms (red, inflamed skin, hair loss at the base of the tail), and basic treatment concepts.
*   **Ringworm:** Recognizing the classic circular patches and understanding it's highly contagious (even to humans).
*   **Mange (Sarcoptic vs Demodectic):** The difference between the highly itchy, contagious scabies and the immune-system-related demodex mites.
*   **Hot Spots (Acute Moist Dermatitis):** Why they appear so suddenly and the importance of keeping the area dry and clean.

### 3. Grooming Tips
**Goal:** Provide actionable, step-by-step guidance on keeping a pet clean.
*   **Bathing Basics:** How often should you bathe your pet? (Not too often to avoid stripping natural oils).
*   **Choosing the Right Shampoo:** Why you should never use human shampoo. The benefits of oatmeal or hypoallergenic pet shampoos.
*   **Nail Trimming:** Why overgrown nails can cause skin and posture issues. Step-by-step safe trimming.
*   **Ear Cleaning:** Identifying healthy ears vs. ear infections (smell, discharge), and how to safely clean them.

### 4. Nutrition
**Goal:** Connect diet and internal health directly to coat and skin appearance.
*   **The Power of Omegas:** How Omega-3 and Omega-6 fatty acids (found in fish oil, flaxseed) contribute to a shiny, resilient coat.
*   **Hydration:** Why water is crucial for skin elasticity.
*   **Identifying Food Allergies:** Common allergens (beef, dairy, wheat) and signs that your pet's itchy skin might be caused by their bowl.
*   **Quality Protein:** The role of protein in replacing hair and skin cells.

### 5. Preventive Care
**Goal:** Strategies to prevent skin issues before they happen.
*   **Flea & Tick Prevention:** A breakdown of topicals, collars, and oral preventatives. The importance of year-round coverage.
*   **Seasonal Skin Care:**
    *   *Summer:* Sunburn risks for light-haired pets, hot pavement paw pad burns.
    *   *Winter:* Dry indoor heating, protecting paws from ice and road salt.
*   **Hygiene & Environment:** Keeping pet beds clean, using pet-safe household cleaners to avoid contact dermatitis.

### 6. First Aid Guide
**Goal:** Emergency protocols for acute skin injuries or reactions.
*   **The Pet First Aid Kit:** Essential items to have on hand (gauze, pet-safe antiseptic, tweezers).
*   **Cuts & Scrapes:** How to safely clean a minor wound and when a vet visit is mandatory.
*   **Insect Stings & Bites:** Identifying localized swelling vs. a severe allergic reaction (anaphylaxis).
*   **Dealing with Rapid Swelling or Hives:** Immediate steps to take and stabilizing the pet for transport to the emergency vet.

## Next Steps
1.  Review and approve the content outlines.
2.  Create the `ActivityManualDetail` class and its corresponding XML layout.
3.  Set up the intent logic in `ActivityPetCareManual` to route clicks correctly.
4.  (Optional) Create a local SQLite database or JSON file to hold the content to keep the Activity code clean.