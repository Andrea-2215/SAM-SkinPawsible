package com.example.skinpawsible

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton

fun setupBottomNavigation(activity: AppCompatActivity, activeItemId: Int) {
    val bottomNav = activity.findViewById<BottomNavigationView>(R.id.bottomNavigation) ?: return
    val fabScan = activity.findViewById<FloatingActionButton>(R.id.fabScan)

    // Push the whole bottom nav container up above the system nav bar
    val bottomNavContainer = activity.findViewById<android.view.View>(R.id.bottomNavInclude)
    bottomNavContainer?.let { container ->
        ViewCompat.setOnApplyWindowInsetsListener(container) { view, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.updatePadding(bottom = systemBars.bottom)
            insets
        }
    }

    // Safely clear Material 3 dark oval background overlay using ColorStateList
    bottomNav.itemActiveIndicatorColor = ColorStateList.valueOf(Color.TRANSPARENT)

    // Force-load icon drawables so physical Samsung devices don't drop them
    bottomNav.menu.findItem(R.id.nav_home)?.icon = ContextCompat.getDrawable(activity, R.drawable.ic_home)
    bottomNav.menu.findItem(R.id.nav_history)?.icon = ContextCompat.getDrawable(activity, R.drawable.ic_history)
    bottomNav.menu.findItem(R.id.nav_manual)?.icon = ContextCompat.getDrawable(activity, R.drawable.ic_book)
    bottomNav.menu.findItem(R.id.nav_profile)?.icon = ContextCompat.getDrawable(activity, R.drawable.ic_profile)

    // State list: Active state = Dark/Black, Inactive state = Medium Grey
    val states = arrayOf(
        intArrayOf(android.R.attr.state_checked),
        intArrayOf(-android.R.attr.state_checked)
    )

    val colors = intArrayOf(
        ContextCompat.getColor(activity, R.color.black),    // Dark active tab
        ContextCompat.getColor(activity, R.color.gray_text)  // Inactive tabs
    )

    val colorStateList = ColorStateList(states, colors)

    bottomNav.itemIconTintList = colorStateList
    bottomNav.itemTextColor = colorStateList

    if (activeItemId > 0) {
        bottomNav.selectedItemId = activeItemId
    } else {
        bottomNav.menu.setGroupCheckable(0, true, false)
        for (i in 0 until bottomNav.menu.size()) {
            bottomNav.menu.getItem(i).isChecked = false
        }
        bottomNav.menu.setGroupCheckable(0, true, true)
    }

    // Handle activity switches
    bottomNav.setOnItemSelectedListener { item ->
        // Prevent clicks on the center placeholder slot for the FAB
        if (item.itemId == R.id.nav_placeholder) return@setOnItemSelectedListener false

        if (activeItemId > 0 && item.itemId == activeItemId) return@setOnItemSelectedListener true

        when (item.itemId) {
            R.id.nav_home -> {
                activity.startActivity(Intent(activity, ActivityHome::class.java))
                true
            }
            R.id.nav_history -> {
                activity.startActivity(Intent(activity, ActivityHistory::class.java))
                true
            }
            R.id.nav_manual -> {
                activity.startActivity(Intent(activity, ActivityPetCareManual::class.java))
                true
            }
            R.id.nav_profile -> {
                activity.startActivity(Intent(activity, ActivityProfile::class.java))
                true
            }
            else -> false
        }
    }

    fabScan?.setOnClickListener {
        activity.startActivity(Intent(activity, ActivityPetScanner::class.java))
    }
}