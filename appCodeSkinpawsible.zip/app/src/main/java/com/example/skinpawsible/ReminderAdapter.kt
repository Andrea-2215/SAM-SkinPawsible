package com.example.skinpawsible

import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

sealed class ReminderListItem {
    data class Header(val title: String, val isExpanded: Boolean = true, val isCompletedHeader: Boolean = false) : ReminderListItem()
    data class Item(val reminder: ReminderItem) : ReminderListItem()
}

class ReminderAdapter(
    private var displayList: MutableList<ReminderListItem>,
    private val onItemClicked: (ReminderItem) -> Unit,
    private val onToggleChanged: (ReminderItem, Boolean) -> Unit,
    private val onMarkDoneClicked: (ReminderItem) -> Unit,
    private val onDeleteClicked: (ReminderItem) -> Unit,
    private val onCompletedHeaderClicked: () -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val TYPE_HEADER = 0
        private const val TYPE_ITEM = 1
    }

    class HeaderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val llHeaderContainer: View = itemView.findViewById(R.id.llHeaderContainer)
        val tvHeaderTitle: TextView = itemView.findViewById(R.id.tvHeaderTitle)
        val ivArrow: ImageView = itemView.findViewById(R.id.ivArrow)
    }

    class ReminderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val cardReminder: MaterialCardView = itemView.findViewById(R.id.cardReminder)
        val flIconBg: FrameLayout = itemView.findViewById(R.id.flIconBg)
        val ivCategoryIcon: ImageView = itemView.findViewById(R.id.ivCategoryIcon)
        val tvTitle: TextView = itemView.findViewById(R.id.tvTitle)
        val tvCategoryTag: TextView = itemView.findViewById(R.id.tvCategoryTag)
        val tvVetBadge: TextView = itemView.findViewById(R.id.tvVetBadge)
        val tvTodayBadge: TextView = itemView.findViewById(R.id.tvTodayBadge)
        val switchEnable: SwitchCompat = itemView.findViewById(R.id.switchEnable)
        val tvPetAndSchedule: TextView = itemView.findViewById(R.id.tvPetAndSchedule)
        val tvNotes: TextView = itemView.findViewById(R.id.tvNotes)
        val tvCompletedBadge: TextView = itemView.findViewById(R.id.tvCompletedBadge)
        val btnMarkDone: MaterialButton = itemView.findViewById(R.id.btnMarkDone)
        val btnDelete: ImageButton = itemView.findViewById(R.id.btnDelete)
    }

    override fun getItemViewType(position: Int): Int {
        return when (displayList[position]) {
            is ReminderListItem.Header -> TYPE_HEADER
            is ReminderListItem.Item -> TYPE_ITEM
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == TYPE_HEADER) {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_reminder_header, parent, false)
            HeaderViewHolder(view)
        } else {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_reminder, parent, false)
            ReminderViewHolder(view)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val listItem = displayList[position]) {
            is ReminderListItem.Header -> {
                val headerHolder = holder as HeaderViewHolder
                headerHolder.tvHeaderTitle.text = listItem.title

                if (listItem.isCompletedHeader) {
                    headerHolder.ivArrow.visibility = View.VISIBLE
                    headerHolder.ivArrow.rotation = if (listItem.isExpanded) 90f else 0f
                    headerHolder.llHeaderContainer.setOnClickListener {
                        onCompletedHeaderClicked()
                    }
                } else {
                    headerHolder.ivArrow.visibility = View.GONE
                    headerHolder.llHeaderContainer.setOnClickListener(null)
                }
            }
            is ReminderListItem.Item -> {
                val itemHolder = holder as ReminderViewHolder
                val item = listItem.reminder

                itemHolder.tvTitle.text = item.title
                itemHolder.tvCategoryTag.text = item.category.displayName
                itemHolder.tvPetAndSchedule.text = "${item.petName} • ${item.dateTimeText} • ${item.repeatText}"

                // Vet Prescribed Badge
                if (item.isVetPrescribed) {
                    itemHolder.tvVetBadge.visibility = View.VISIBLE
                    itemHolder.tvVetBadge.text = "Created by Vet: ${item.createdBy}"
                } else {
                    itemHolder.tvVetBadge.visibility = View.GONE
                }

                // Today Alert Badge
                if (isDateToday(item.dateTimeText) && !item.isCompleted && item.isEnabled) {
                    itemHolder.tvTodayBadge.visibility = View.VISIBLE
                    itemHolder.tvTodayBadge.text = "Scheduled for Today!"
                } else {
                    itemHolder.tvTodayBadge.visibility = View.GONE
                }

                // Category Icon & Background Tint
                itemHolder.ivCategoryIcon.setImageResource(item.category.iconRes)
                itemHolder.ivCategoryIcon.imageTintList = ColorStateList.valueOf(item.category.iconTintHex.toInt())
                itemHolder.flIconBg.backgroundTintList = ColorStateList.valueOf(item.category.bgColorHex.toInt())

                // Notes
                if (item.notes.isNotBlank()) {
                    itemHolder.tvNotes.visibility = View.VISIBLE
                    itemHolder.tvNotes.text = "Note: ${item.notes}"
                } else {
                    itemHolder.tvNotes.visibility = View.GONE
                }

                // Toggle Switch State
                itemHolder.switchEnable.setOnCheckedChangeListener(null)
                itemHolder.switchEnable.isChecked = item.isEnabled
                itemHolder.switchEnable.setOnCheckedChangeListener { _, isChecked ->
                    item.isEnabled = isChecked
                    updateCardAlpha(itemHolder, item)
                    onToggleChanged(item, isChecked)
                }

                // Completed vs Active Action Styling
                if (item.isCompleted) {
                    itemHolder.tvCompletedBadge.visibility = View.VISIBLE
                    itemHolder.btnMarkDone.text = "Undo"
                    itemHolder.btnMarkDone.setBackgroundColor(Color.parseColor("#F3EDF7"))
                    itemHolder.btnMarkDone.setTextColor(Color.parseColor("#6A3FA0"))
                } else {
                    itemHolder.tvCompletedBadge.visibility = View.GONE
                    itemHolder.btnMarkDone.text = "Mark as Done"
                    itemHolder.btnMarkDone.setBackgroundColor(Color.parseColor("#F3EDF7"))
                    itemHolder.btnMarkDone.setTextColor(Color.parseColor("#6A3FA0"))
                }

                updateCardAlpha(itemHolder, item)

                itemHolder.cardReminder.setOnClickListener {
                    onItemClicked(item)
                }

                itemHolder.btnMarkDone.setOnClickListener {
                    item.isCompleted = !item.isCompleted
                    onMarkDoneClicked(item)
                }

                itemHolder.btnDelete.setOnClickListener {
                    onDeleteClicked(item)
                }
            }
        }
    }

    private fun isDateToday(dateTimeStr: String): Boolean {
        if (dateTimeStr.contains("Today", ignoreCase = true)) return true
        val todayStr = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Calendar.getInstance().time)
        return dateTimeStr.contains(todayStr, ignoreCase = true)
    }

    private fun updateCardAlpha(holder: ReminderViewHolder, item: ReminderItem) {
        if (!item.isEnabled || item.isCompleted) {
            holder.cardReminder.alpha = 0.65f
        } else {
            holder.cardReminder.alpha = 1.0f
        }
    }

    override fun getItemCount(): Int = displayList.size

    fun updateDisplayList(newList: List<ReminderListItem>) {
        displayList = newList.toMutableList()
        notifyDataSetChanged()
    }
}
