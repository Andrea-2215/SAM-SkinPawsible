package com.example.skinpawsible

import com.google.firebase.firestore.DocumentSnapshot
import java.util.UUID

enum class NotificationType(
    val displayName: String,
    val iconRes: Int,
    val bgColorHex: Long,
    val iconTintHex: Long
) {
    MESSAGE("Messages", R.drawable.ic_chat, 0xFFEDE4F8, 0xFF6A3FA0),
    REMINDER("Reminders", R.drawable.ic_bell, 0xFFFFF3E0, 0xFFFB8C00),
    VET_UPDATE("Vet Updates", R.drawable.ic_medical_history, 0xFFE3F2FD, 0xFF1E88E5),
    SYSTEM("System", R.drawable.ic_paw, 0xFFE8F5E9, 0xFF2E7D32)
}

data class NotificationItem(
    val id: String = UUID.randomUUID().toString(),
    val userId: String = "",
    val title: String = "",
    val message: String = "",
    val timestamp: String = "",
    val createdAtMillis: Long = System.currentTimeMillis(),
    val type: NotificationType = NotificationType.REMINDER,
    val targetScreen: String = "REMINDER", // "CHAT", "REMINDER", "HISTORY"
    val targetId: String = "",
    var isRead: Boolean = false
) {
    fun getFormattedTime(): String {
        val currentTime = System.currentTimeMillis()
        if (createdAtMillis <= 0 || createdAtMillis > currentTime) {
            return if (timestamp.isNotBlank()) timestamp else "Just now"
        }
        val diff = currentTime - createdAtMillis
        val minutes = diff / (1000 * 60)
        val hours = diff / (1000 * 60 * 60)
        val days = diff / (1000 * 60 * 60 * 24)

        return when {
            minutes < 1 -> "Just now"
            minutes < 60 -> "${minutes}m ago"
            hours < 24 -> "${hours}h ago"
            else -> "${days}d ago"
        }
    }

    fun toMap(): HashMap<String, Any> {
        return hashMapOf(
            "id" to id,
            "userId" to userId,
            "title" to title,
            "message" to message,
            "timestamp" to timestamp,
            "createdAtMillis" to createdAtMillis,
            "type" to type.name,
            "targetScreen" to targetScreen,
            "targetId" to targetId,
            "isRead" to isRead
        )
    }

    companion object {
        fun fromDocument(doc: DocumentSnapshot): NotificationItem {
            val typeStr = doc.getString("type") ?: "REMINDER"
            val typeEnum = try {
                NotificationType.valueOf(typeStr)
            } catch (e: Exception) {
                NotificationType.REMINDER
            }

            return NotificationItem(
                id = doc.getString("id") ?: doc.id,
                userId = doc.getString("userId") ?: "",
                title = doc.getString("title") ?: "",
                message = doc.getString("message") ?: "",
                timestamp = doc.getString("timestamp") ?: "Just now",
                createdAtMillis = doc.getLong("createdAtMillis") ?: System.currentTimeMillis(),
                type = typeEnum,
                targetScreen = doc.getString("targetScreen") ?: "REMINDER",
                targetId = doc.getString("targetId") ?: "",
                isRead = doc.getBoolean("isRead") ?: false
            )
        }
    }
}
