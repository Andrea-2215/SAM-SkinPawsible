package com.example.skinpawsible

import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.ChipGroup
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

class ActivityNotifications : BaseActivity() {

    private lateinit var rvNotifications: RecyclerView
    private lateinit var llEmptyState: LinearLayout
    private lateinit var tvUnreadBadge: TextView
    private lateinit var tvMarkAllRead: TextView
    private lateinit var chipGroupFilter: ChipGroup
    private lateinit var adapter: NotificationAdapter

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private var notifListener: ListenerRegistration? = null

    private val allNotifications = mutableListOf<NotificationItem>()
    private var selectedTypeFilter: NotificationType? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notifications)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        // Header Controls
        val btnBack = findViewById<ImageView>(R.id.btnBack)
        btnBack?.setOnClickListener { finish() }

        tvUnreadBadge = findViewById(R.id.tvUnreadBadge)
        tvMarkAllRead = findViewById(R.id.tvMarkAllRead)

        tvMarkAllRead.setOnClickListener {
            allNotifications.forEach { item ->
                if (!item.isRead) {
                    item.isRead = true
                    db.collection("notifications").document(item.id).update("isRead", true)
                }
            }
            applyFilters()
            updateUnreadBadge()
            Toast.makeText(this, "All notifications marked as read", Toast.LENGTH_SHORT).show()
        }

        // Views
        rvNotifications = findViewById(R.id.rvNotifications)
        llEmptyState = findViewById(R.id.llEmptyState)
        chipGroupFilter = findViewById(R.id.chipGroupFilter)

        // RecyclerView
        rvNotifications.layoutManager = LinearLayoutManager(this)

        adapter = NotificationAdapter(
            displayList = groupNotificationsByDate(getFilteredNotifications()).toMutableList(),
            onNotificationClicked = { item ->
                db.collection("notifications").document(item.id).update("isRead", true)
                updateUnreadBadge()
                navigateToTarget(item)
            }
        )
        rvNotifications.adapter = adapter

        setupSwipeToDelete()
        setupFilterListeners()
    }

    override fun onStart() {
        super.onStart()
        listenToNotifications()
    }

    override fun onStop() {
        super.onStop()
        notifListener?.remove()
    }

    private fun listenToNotifications() {
        val currentUser = auth.currentUser ?: return

        notifListener?.remove()
        notifListener = db.collection("notifications")
            .whereEqualTo("userId", currentUser.uid)
            .addSnapshotListener { snapshots, error ->
                if (error != null) {
                    Toast.makeText(this, "Failed to load notifications: ${error.message}", Toast.LENGTH_SHORT).show()
                    return@addSnapshotListener
                }

                allNotifications.clear()
                if (snapshots != null && !snapshots.isEmpty) {
                    for (doc in snapshots.documents) {
                        allNotifications.add(NotificationItem.fromDocument(doc))
                    }
                }
                applyFilters()
                updateUnreadBadge()
            }
    }

    private fun setupSwipeToDelete() {
        val swipeHandler = object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean = false

            override fun getSwipeDirs(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder): Int {
                val pos = viewHolder.adapterPosition
                val notif = adapter.getNotificationAt(pos)
                return if (notif == null) 0 else super.getSwipeDirs(recyclerView, viewHolder)
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val pos = viewHolder.adapterPosition
                val notif = adapter.getNotificationAt(pos)
                if (notif != null) {
                    db.collection("notifications").document(notif.id).delete()
                        .addOnSuccessListener {
                            Toast.makeText(this@ActivityNotifications, "Notification deleted", Toast.LENGTH_SHORT).show()
                        }
                }
            }

            override fun onChildDraw(
                c: Canvas,
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                dX: Float,
                dY: Float,
                actionState: Int,
                isCurrentlyActive: Boolean
            ) {
                val itemView = viewHolder.itemView
                val background = ColorDrawable(Color.parseColor("#FFEBEE"))

                if (dX < 0) {
                    background.setBounds(
                        itemView.right + dX.toInt(),
                        itemView.top,
                        itemView.right,
                        itemView.bottom
                    )
                    background.draw(c)
                }

                super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive)
            }
        }

        ItemTouchHelper(swipeHandler).attachToRecyclerView(rvNotifications)
    }

    private fun groupNotificationsByDate(items: List<NotificationItem>): List<NotificationListItem> {
        if (items.isEmpty()) return emptyList()

        val sortedItems = items.sortedByDescending { it.createdAtMillis }

        val todayList = mutableListOf<NotificationItem>()
        val yesterdayList = mutableListOf<NotificationItem>()
        val earlierList = mutableListOf<NotificationItem>()

        val now = System.currentTimeMillis()
        val oneDayMillis = 24 * 60 * 60 * 1000L

        for (item in sortedItems) {
            val diff = now - item.createdAtMillis
            when {
                diff < oneDayMillis -> todayList.add(item)
                diff < 2 * oneDayMillis -> yesterdayList.add(item)
                else -> earlierList.add(item)
            }
        }

        val result = mutableListOf<NotificationListItem>()

        if (todayList.isNotEmpty()) {
            result.add(NotificationListItem.Header("Today"))
            todayList.forEach { result.add(NotificationListItem.Item(it)) }
        }

        if (yesterdayList.isNotEmpty()) {
            result.add(NotificationListItem.Header("Yesterday"))
            yesterdayList.forEach { result.add(NotificationListItem.Item(it)) }
        }

        if (earlierList.isNotEmpty()) {
            result.add(NotificationListItem.Header("Earlier"))
            earlierList.forEach { result.add(NotificationListItem.Item(it)) }
        }

        return result
    }

    private fun navigateToTarget(item: NotificationItem) {
        when (item.targetScreen) {
            "CHAT" -> {
                val intent = Intent(this, ActivityChat::class.java)
                intent.putExtra("vetName", item.title)
                startActivity(intent)
            }
            "REMINDER" -> {
                val intent = Intent(this, ActivityReminders::class.java)
                if (item.targetId.isNotEmpty()) {
                    intent.putExtra("highlightTitle", item.targetId)
                }
                startActivity(intent)
            }
            "HISTORY" -> {
                val intent = Intent(this, ActivityHistory::class.java)
                startActivity(intent)
            }
            else -> {
                Toast.makeText(this, item.title, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateUnreadBadge() {
        val unreadCount = allNotifications.count { !it.isRead }
        if (unreadCount > 0) {
            tvUnreadBadge.visibility = View.VISIBLE
            tvUnreadBadge.text = "$unreadCount New"
        } else {
            tvUnreadBadge.visibility = View.GONE
        }
    }

    private fun setupFilterListeners() {
        chipGroupFilter.setOnCheckedStateChangeListener { _, checkedIds ->
            selectedTypeFilter = when {
                checkedIds.contains(R.id.chipFilterMessages) -> NotificationType.MESSAGE
                checkedIds.contains(R.id.chipFilterReminders) -> NotificationType.REMINDER
                checkedIds.contains(R.id.chipFilterVet) -> NotificationType.VET_UPDATE
                else -> null
            }
            applyFilters()
        }
    }

    private fun getFilteredNotifications(): List<NotificationItem> {
        return allNotifications.filter { item ->
            selectedTypeFilter == null || item.type == selectedTypeFilter
        }
    }

    private fun applyFilters() {
        val filteredList = getFilteredNotifications()
        val groupedDisplayList = groupNotificationsByDate(filteredList)
        adapter.updateDisplayList(groupedDisplayList)

        if (groupedDisplayList.isEmpty()) {
            rvNotifications.visibility = View.GONE
            llEmptyState.visibility = View.VISIBLE
        } else {
            rvNotifications.visibility = View.VISIBLE
            llEmptyState.visibility = View.GONE
        }
    }


}
