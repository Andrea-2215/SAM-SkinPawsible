package com.example.skinpawsible

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ScrollView
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import com.google.android.material.card.MaterialCardView

class ActivityManualDetail : BaseActivity() {

    private lateinit var btnBack: ImageButton
    private lateinit var tvTitle: TextView
    private lateinit var containerContent: LinearLayout
    private lateinit var scrollViewDetail: ScrollView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manual_detail)

        btnBack = findViewById(R.id.btnBack)
        tvTitle = findViewById(R.id.tvTitle)
        containerContent = findViewById(R.id.containerContent)
        scrollViewDetail = findViewById(R.id.scrollViewDetail)

        btnBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        val topicId = intent.getStringExtra("EXTRA_TOPIC_ID") ?: ""
        loadContent(topicId)

        val targetSection = intent.getStringExtra("EXTRA_TARGET_SECTION") ?: ""
        if (targetSection.isNotEmpty()) {
            scrollToTargetSection(targetSection)
        }
    }

    private fun loadContent(topicId: String) {
        when (topicId) {
            "skin_care_basics" -> {
                tvTitle.text = "Skin Care Basics"
                
                addIntroBanner("Educate yourself on foundational routines for healthy pet skin. A healthy coat is a direct reflection of overall skin health and internal well-being.")

                addSectionCard("Understanding Pet Skin", R.drawable.ic_paw) { layout ->
                    addParagraphToLayout(layout, "The skin is the largest organ of your pet's body. Unlike human skin, which is more acidic, a dog's or cat's skin has a more neutral pH balance. This is why using human shampoos or soaps can disrupt their natural acid mantle, leading to irritation, dryness, and vulnerability to infections.")
                }

                addSectionCard("Daily Routine", R.drawable.ic_grooming) { layout ->
                    addParagraphToLayout(layout, "Establishing a daily routine is crucial for early detection of skin issues. You should perform quick checks daily while petting or cuddling your pet:")
                    addBulletPointToLayout(layout, "Feel for unexpected lumps, bumps, or scabs.")
                    addBulletPointToLayout(layout, "Part the fur to check for redness, rashes, or dry, flaky skin.")
                    addBulletPointToLayout(layout, "Check areas prone to moisture, such as between the paw pads, under the tail, and inside the ears.")
                }

                addSectionCard("Brushing & Coat Checking", R.drawable.ic_paw) { layout ->
                    addParagraphToLayout(layout, "Regular brushing does more than keep your pet looking good; it is a critical health practice. Brushing helps distribute natural skin oils throughout the coat, providing a protective barrier. It also removes dead hair and dirt, preventing mats which can pull on the skin and create moist, warm environments for bacteria and yeast to thrive.")
                }

                addSectionCard("When to be Concerned", R.drawable.ic_first_aid) { layout ->
                    addParagraphToLayout(layout, "According to veterinary guidelines, you should schedule a visit to your vet if you notice any of the following abnormal signs:")
                    addBulletPointToLayout(layout, "Excessive scratching, licking, or chewing of the skin.")
                    addBulletPointToLayout(layout, "Noticeable patches of fur loss (alopecia).")
                    addBulletPointToLayout(layout, "Foul odor coming from the skin or ears.")
                    addBulletPointToLayout(layout, "Persistent flakiness (dandruff) or greasy skin.")
                    addBulletPointToLayout(layout, "Red, inflamed, or hot areas on the body.")
                }
            }
            "common_diseases" -> {
                tvTitle.text = "Common Skin Diseases"

                addIntroBanner("Sourced from the Merck Veterinary Manual. Early recognition and veterinary diagnosis are crucial for effective management and your pet's comfort.")

                addSectionCard("Flea Allergy Dermatitis (FAD)", R.drawable.ic_bug) { layout ->
                    addParagraphToLayout(layout, "Flea Allergy Dermatitis (FAD) is the most common cause of allergic skin disease in dogs and cats. It is triggered by an allergic hypersensitivity reaction to proteins in flea saliva injected during feeding.")
                    addParagraphToLayout(layout, "Key Merck Vet Insights & Symptoms:")
                    addBulletPointToLayout(layout, "Intense itching (pruritus), hair loss (alopecia), and inflamed red skin.")
                    addBulletPointToLayout(layout, "Lesions concentrate around the base of the tail, lower back, inner thighs, and groin.")
                    addBulletPointToLayout(layout, "A single flea bite can cause severe, continuous itching that lasts for days in sensitive animals.")
                    addParagraphToLayout(layout, "Management & Care:")
                    addBulletPointToLayout(layout, "Strict, year-round preventive flea control for all household pets.")
                    addBulletPointToLayout(layout, "Veterinary anti-pruritic medications to calm acute skin inflammation.")
                    addBulletPointToLayout(layout, "Environmental cleaning and vacuuming to eliminate eggs and larvae.")
                }

                addSectionCard("Ringworm (Dermatophytosis)", R.drawable.ic_ringworm_badge) { layout ->
                    addParagraphToLayout(layout, "Despite its name, ringworm is a superficial fungal infection affecting hair shafts, skin, and claws. It is primarily caused by Microsporum or Trichophyton fungal species.")
                    addParagraphToLayout(layout, "Key Merck Vet Insights & Symptoms:")
                    addBulletPointToLayout(layout, "Circular patches of hair loss with crusty, flaky, or reddened outer borders.")
                    addBulletPointToLayout(layout, "Brittle hair shafts that break off near the skin surface.")
                    addBulletPointToLayout(layout, "Zoonotic Alert: Highly contagious to other pets and humans, especially children and elderly family members.")
                    addParagraphToLayout(layout, "Management & Care:")
                    addBulletPointToLayout(layout, "Veterinary diagnostic confirmation via fungal culture (DTM), PCR test, or Wood's lamp.")
                    addBulletPointToLayout(layout, "Topical medicated baths/dips combined with systemic antifungal medication.")
                    addBulletPointToLayout(layout, "Thorough environmental decontamination to remove persistent fungal spores.")
                }

                addSectionCard("Mange (Sarcoptic vs. Demodectic)", R.drawable.ic_microscope) { layout ->
                    addParagraphToLayout(layout, "Mange is caused by microscopic skin mites. Differentiating between Sarcoptic and Demodectic mange is vital for proper treatment.")
                    addParagraphToLayout(layout, "Sarcoptic Mange (Scabies):")
                    addBulletPointToLayout(layout, "Caused by Sarcoptes scabiei mites burrowing into outer skin layers.")
                    addBulletPointToLayout(layout, "Extremely contagious with unremitting, intense itching. Commonly affects ear margins, elbows, and belly.")
                    addBulletPointToLayout(layout, "Can cause temporary itchy papules on human skin contact.")
                    addParagraphToLayout(layout, "Demodectic Mange (Demodex):")
                    addBulletPointToLayout(layout, "Caused by overproliferation of microscopic mites living in hair follicles.")
                    addBulletPointToLayout(layout, "Not contagious. Localized forms present as mild patchy hair loss on face or legs.")
                    addParagraphToLayout(layout, "Management & Care:")
                    addBulletPointToLayout(layout, "Requires veterinary skin scrapings or hair plucks for microscopic identification.")
                    addBulletPointToLayout(layout, "Treated with targeted parasiticide medications under veterinary direction.")
                }

                addSectionCard("Hot Spots (Acute Moist Dermatitis)", R.drawable.ic_flame) { layout ->
                    addParagraphToLayout(layout, "Hot spots are rapidly developing localized areas of painful, moist skin inflammation and surface bacterial infection caused by self-trauma (licking, biting, scratching).")
                    addParagraphToLayout(layout, "Key Merck Vet Insights & Symptoms:")
                    addBulletPointToLayout(layout, "Common Triggers: Flea bites, ear infections, wet matted fur, or underlying food/environmental allergies.")
                    addBulletPointToLayout(layout, "Rapid Progression: Can develop and expand within a few hours.")
                    addBulletPointToLayout(layout, "Lesions are red, moist, oozing, warm to touch, and highly sensitive/painful.")
                    addParagraphToLayout(layout, "Management & Care:")
                    addBulletPointToLayout(layout, "Gently clip hair around the spot to expose skin to air and promote drying.")
                    addBulletPointToLayout(layout, "Cleanse with veterinary antiseptic solution (e.g., chlorhexidine).")
                    addBulletPointToLayout(layout, "Use an e-collar (cone) to stop self-trauma while getting prompt veterinary assistance.")
                }

                addSectionCard("Yeast Dermatitis (Malassezia)", R.drawable.ic_yeast_badge) { layout ->
                    addParagraphToLayout(layout, "Malassezia pachydermatitis is an opportunistic yeast that normally inhabits pet skin. It overgrows when skin humidity is high or skin barriers are disrupted.")
                    addParagraphToLayout(layout, "Key Merck Vet Insights & Symptoms:")
                    addBulletPointToLayout(layout, "Greasy, thickened skin, dark pigmentation (hyperpigmentation), and persistent itching.")
                    addBulletPointToLayout(layout, "Distinctive musty or 'sweet rancid' odor from ears or skin folds.")
                    addBulletPointToLayout(layout, "Frequently targets ear canals, paw pads, skin folds, neck, and armpits.")
                    addParagraphToLayout(layout, "Management & Care:")
                    addBulletPointToLayout(layout, "Cytology impression smear performed by a vet to confirm yeast counts.")
                    addBulletPointToLayout(layout, "Antifungal shampoos, wipes, or oral treatment along with addressing underlying allergies.")
                }

                addSectionCard("Bacterial Pyoderma", R.drawable.ic_bacteria) { layout ->
                    addParagraphToLayout(layout, "Pyoderma is a bacterial skin infection, usually caused by Staphylococcus pseudintermedius. It is almost always secondary to underlying health or allergy issues.")
                    addParagraphToLayout(layout, "Key Merck Vet Insights & Symptoms:")
                    addBulletPointToLayout(layout, "Pustules (pus-filled bumps), papules, and circular crusting skin patches ('epidermal collarettes').")
                    addBulletPointToLayout(layout, "Scaling, flakiness, and localized hair loss.")
                    addParagraphToLayout(layout, "Management & Care:")
                    addBulletPointToLayout(layout, "Veterinary examination to identify and treat the underlying primary trigger.")
                    addBulletPointToLayout(layout, "Topical antibacterial washes and targeted antibiotic therapy if necessary.")
                }

                addSectionCard("Allergic Dermatitis (Atopy)", R.drawable.ic_allergies) { layout ->
                    addParagraphToLayout(layout, "Atopic dermatitis is an inflammatory, allergic skin disease caused by hypersensitivity to environmental allergens such as dust mites, pollen, or molds.")
                    addParagraphToLayout(layout, "Key Merck Vet Insights & Symptoms:")
                    addBulletPointToLayout(layout, "Recurrent paw licking, face rubbing, groin/armpit redness, and frequent ear infections.")
                    addBulletPointToLayout(layout, "Often manifests in young pets (1 to 3 years old) with seasonal flare-ups.")
                    addParagraphToLayout(layout, "Management & Care:")
                    addBulletPointToLayout(layout, "Veterinary-guided therapy (anti-pruritic treatments, targeted allergen immunotherapy).")
                    addBulletPointToLayout(layout, "Regular therapeutic bathing to wash off pollen and allergens from the coat.")
                }
            }
            "grooming_tips" -> {
                tvTitle.text = "Grooming Tips"

                addIntroBanner("Sourced from the Merck Veterinary Manual. Proper grooming maintains skin barrier health, prevents matting, and enables early detection of skin problems.")

                addSectionCard("Bathing Basics & Frequency", R.drawable.ic_bathtub) { layout ->
                    addParagraphToLayout(layout, "Bathing keeps coat and skin clean, but excessive bathing strips natural epidermal lipids, leading to dry skin, irritation, and seborrhea.")
                    addParagraphToLayout(layout, "Key Merck Vet Insights & Steps:")
                    addBulletPointToLayout(layout, "Frequency: Most healthy pets only need bathing every 4 to 8 weeks unless dirty or recommended by a vet.")
                    addBulletPointToLayout(layout, "Pre-Bath Brushing: Always thoroughly brush out mats and loose hair before wetting; wet mats shrink and tighten against skin.")
                    addBulletPointToLayout(layout, "Water Temperature: Use lukewarm water. Hot water causes skin inflammation and intensifies pre-existing itching.")
                    addBulletPointToLayout(layout, "Ear Protection: Gently place cotton balls in ear canals during bathing to prevent water entry and subsequent ear infections.")
                }

                addSectionCard("Choosing the Right Shampoo", R.drawable.ic_shampoo) { layout ->
                    addParagraphToLayout(layout, "Pet skin has a neutral to slightly alkaline pH (6.5 to 7.5), while human skin is acidic (4.5 to 5.5). Using human shampoo strips the protective acid mantle of pet skin.")
                    addParagraphToLayout(layout, "Key Merck Vet Insights:")
                    addBulletPointToLayout(layout, "Always use species-formulated, pH-balanced pet shampoos (such as colloidal oatmeal or aloe vera formulas).")
                    addBulletPointToLayout(layout, "Medicated Shampoos: Anti-fungal or antibacterial shampoos require a 5 to 10 minute skin contact time before rinsing to be effective.")
                    addBulletPointToLayout(layout, "Thorough Rinsing: Residual soap left on skin is a major cause of contact irritation, itching, and flaking.")
                }

                addSectionCard("Coat Brushing & De-Shedding", R.drawable.ic_brush) { layout ->
                    addParagraphToLayout(layout, "Brushing distributes natural skin oils (sebum) along the hair shaft, improves cutaneous blood circulation, and prevents painful hair matting.")
                    addParagraphToLayout(layout, "Brushing Techniques by Coat Type:")
                    addBulletPointToLayout(layout, "Short Coats: Use rubber curry brushes or soft bristle brushes to remove loose hair and stimulate skin oils.")
                    addBulletPointToLayout(layout, "Double Coats / Heavy Shedders: Use undercoat rakes to remove dead undercoat without damaging topcoat guard hairs.")
                    addBulletPointToLayout(layout, "Long / Curly Coats: Use slicker brushes and metal line combs daily. Never cut severe mats with scissors due to risk of cutting thin skin underneath.")
                }

                addSectionCard("Ear Cleaning & Care", R.drawable.ic_ear_care) { layout ->
                    addParagraphToLayout(layout, "Canine and feline ear canals have an L-shaped structure that traps wax, moisture, and debris. Regular, gentle cleaning helps prevent otitis externa.")
                    addParagraphToLayout(layout, "Safe Ear Cleaning Steps:")
                    addBulletPointToLayout(layout, "Use dedicated veterinary ear cleanser. Never use rubbing alcohol, hydrogen peroxide, or plain water.")
                    addBulletPointToLayout(layout, "Fill ear canal with cleanser, gently massage the ear base (listen for squishing sound), and allow pet to shake head.")
                    addBulletPointToLayout(layout, "Wipe external ear flap and upper canal with a soft cotton pad.")
                    addBulletPointToLayout(layout, "Warning: Never insert Q-tips deep into ear canals, as this packs debris down and can puncture the ear drum.")
                }

                addSectionCard("Nail Trimming & Paw Care", R.drawable.ic_paw) { layout ->
                    addParagraphToLayout(layout, "Overgrown nails alter paw biomechanics, leading to joint strain, splayed toes, and painful torn nails.")
                    addParagraphToLayout(layout, "Paw & Nail Maintenance Tips:")
                    addBulletPointToLayout(layout, "Trim nails every 3 to 4 weeks using dedicated pet nail clippers.")
                    addBulletPointToLayout(layout, "Locate the 'quick' (blood vessel). On dark nails, trim small slivers until a dark pinkish spot appears in the center.")
                    addBulletPointToLayout(layout, "Keep styptic powder or cornstarch ready in case of accidental quick nicking.")
                    addBulletPointToLayout(layout, "Inspect paw pads regularly for cracks or foreign material, and trim hair between pads to prevent mud/ice buildup.")
                }
            }
            "nutrition" -> {
                tvTitle.text = "Nutrition & Skin Health"

                addIntroBanner("Sourced from the Merck Veterinary Manual. Up to 30% of a pet's daily dietary protein goes toward skin and coat renewal. Diet directly dictates skin barrier resilience.")

                addSectionCard("Essential Fatty Acids (Omegas)", R.drawable.ic_fish_omega) { layout ->
                    addParagraphToLayout(layout, "Essential fatty acids (EFAs) are required structural components of skin cell membranes. Pets cannot produce them internally and must obtain them through diet.")
                    addParagraphToLayout(layout, "Key Merck Vet Insights:")
                    addBulletPointToLayout(layout, "Omega-6 (Linoleic Acid): Restores epidermal moisture lipid barriers, preventing dry, lusterless fur and skin scaling.")
                    addBulletPointToLayout(layout, "Omega-3 (EPA & DHA): Derived from cold-water fish oils; acts as a natural anti-inflammatory agent that reduces itching in allergic skin disease.")
                    addBulletPointToLayout(layout, "Optimal Balance: A controlled ratio of Omega-6 to Omega-3 (between 5:1 and 10:1) boosts coat shine while lowering systemic skin inflammation.")
                }

                addSectionCard("Protein & Keratin Synthesis", R.drawable.ic_protein) { layout ->
                    addParagraphToLayout(layout, "Hair strands and the outer epidermal layer are composed almost entirely of keratin protein. High protein quality is essential for coat renewal.")
                    addParagraphToLayout(layout, "Key Merck Vet Insights:")
                    addBulletPointToLayout(layout, "Sulfur Amino Acids: Methionine and cysteine are critical for keratin cross-linking, giving hair tensile strength.")
                    addBulletPointToLayout(layout, "Deficiency Signs: Protein deficiencies cause brittle hair, fur depigmentation (color fading), slow wound healing, and thin skin.")
                    addBulletPointToLayout(layout, "Animal Proteins: Highly digestible animal-based proteins (chicken, salmon, lamb, egg) provide complete amino acid profiles needed for hair replacement.")
                }

                addSectionCard("Hydration & Skin Elasticity", R.drawable.ic_water_drop) { layout ->
                    addParagraphToLayout(layout, "Cellular hydration maintains skin elasticity (turgor) and prevents micro-cracking in the epidermal barrier.")
                    addParagraphToLayout(layout, "Key Merck Vet Insights:")
                    addBulletPointToLayout(layout, "Dehydration Impact: Mild chronic dehydration decreases skin perfusion, exacerbating flakiness and itching.")
                    addBulletPointToLayout(layout, "Moisture-Rich Foods: Incorporating wet canned food increases total water intake, especially beneficial for cats with low thirst drives.")
                    addBulletPointToLayout(layout, "Clean Water Access: Provide fresh water in stainless steel or ceramic bowls (plastic bowls can harbor bacteria causing chin pyoderma).")
                }

                addSectionCard("Adverse Food Reactions & Allergies", R.drawable.ic_food_bowl) { layout ->
                    addParagraphToLayout(layout, "Adverse Food Reactions (AFR) account for 10% to 15% of allergic skin diseases in pets. It is an immune reaction to dietary glycoproteins.")
                    addParagraphToLayout(layout, "Key Merck Vet Insights & Symptoms:")
                    addBulletPointToLayout(layout, "Common Triggers: Beef, dairy, chicken, wheat, soy, and lamb are the most frequent dietary allergens in dogs and cats.")
                    addBulletPointToLayout(layout, "Symptoms: Year-round non-seasonal itching, recurrent ear infections (otitis), paw licking, and soft stools.")
                    addBulletPointToLayout(layout, "Age Onset: Can develop at any age, even after eating the same diet for years without prior issues.")
                }

                addSectionCard("Veterinary Elimination Diet Trials", R.drawable.ic_microscope) { layout ->
                    addParagraphToLayout(layout, "Veterinary dermatologists emphasize that blood and saliva food allergy tests are unreliable. A strict elimination diet trial is the gold standard diagnostic method.")
                    addParagraphToLayout(layout, "Diagnostic Trial Protocol:")
                    addBulletPointToLayout(layout, "Diet Selection: Feed a novel protein diet (e.g., rabbit, venison) or a prescription hydrolyzed diet for 8 to 12 weeks.")
                    addBulletPointToLayout(layout, "Strict Compliance: Zero treats, table scraps, flavored medications, or chew treats during the trial period.")
                    addBulletPointToLayout(layout, "Confirmatory Challenge: Reintroducing former food to confirm if itching returns within 14 days validates the diagnosis.")
                }
            }
            "preventive_care" -> {
                tvTitle.text = "Preventive Care"

                addIntroBanner("Sourced from the Merck Veterinary Manual. Proactive parasite prevention, seasonal care, and home hygiene prevent minor irritations from escalating into severe skin diseases.")

                addSectionCard("Year-Round Flea & Tick Control", R.drawable.ic_shield_check) { layout ->
                    addParagraphToLayout(layout, "Ectoparasites transmit systemic pathogens and cause severe allergic skin disease. Year-round preventive coverage is essential, even in cold climates.")
                    addParagraphToLayout(layout, "Key Merck Vet Guidelines:")
                    addBulletPointToLayout(layout, "Preventative Modalities: Modern oral isoxazolines (fluralaner, sarolaner, afoxolaner), spot-on topicals, or impregnated collars.")
                    addBulletPointToLayout(layout, "Multi-Pet Households: Treat all household dogs and cats simultaneously; untreated pets serve as continuous flea reservoirs.")
                    addBulletPointToLayout(layout, "Environmental Sanitation: Regularly vacuum pet sleeping areas and wash bedding in hot water (>60°C) to destroy eggs and larvae.")
                }

                addSectionCard("Seasonal Skin Protection", R.drawable.ic_sun_snow) { layout ->
                    addParagraphToLayout(layout, "Environmental extremes present unique threats to skin barrier integrity across different seasons.")
                    addParagraphToLayout(layout, "Summer Care Guidelines:")
                    addBulletPointToLayout(layout, "Sunburn Protection: Light-colored or thin-haired pets risk solar dermatitis on ears, nose, and belly. Avoid peak UV hours or apply pet-safe sunscreen (never human zinc-based sunscreen).")
                    addBulletPointToLayout(layout, "Hot Pavement: Asphalt can cause severe paw pad thermal burns. Always test pavement temperature with your hand for 7 seconds.")
                    addParagraphToLayout(layout, "Winter Care Guidelines:")
                    addBulletPointToLayout(layout, "Dry Air & Heating: Indoor heating strips humidity, causing skin scaling. Protect paws from ice, road salt, and toxic de-icers by washing pads after walks.")
                }

                addSectionCard("Environmental & Contact Hygiene", R.drawable.ic_grooming) { layout ->
                    addParagraphToLayout(layout, "Irritant contact dermatitis occurs when skin contacts harsh household chemicals, abrasive fabrics, or synthetic dyes.")
                    addParagraphToLayout(layout, "Key Merck Vet Recommendations:")
                    addBulletPointToLayout(layout, "Hypoallergenic Laundry: Wash pet bedding with fragrance-free, dye-free detergent. Avoid commercial fabric softeners.")
                    addBulletPointToLayout(layout, "Floor Cleaners: Allow household disinfectants and floor cleaners to dry completely before permitting pet contact.")
                    addBulletPointToLayout(layout, "Bedding Selection: Provide clean, orthopedic, washable beds to prevent pressure sores (elbow hygromas) in large dog breeds.")
                }

                addSectionCard("Routine Nose-to-Tail Inspections", R.drawable.ic_paw) { layout ->
                    addParagraphToLayout(layout, "Conducting regular physical skin checks catches early subtle signs of infection before secondary pyoderma or severe itching sets in.")
                    addParagraphToLayout(layout, "Inspection Checklist:")
                    addBulletPointToLayout(layout, "Perform weekly tactile skin checks feeling for unexpected bumps, crusts, or attached ticks.")
                    addBulletPointToLayout(layout, "Keep a record of seasonal flare-up dates to help your veterinarian diagnose environmental allergies.")
                }
            }
            "first_aid" -> {
                tvTitle.text = "First Aid Guide"

                addIntroBanner("Sourced from the Merck Veterinary Manual. Emergency first-aid stabilization reduces pain and prevents wound infection prior to professional veterinary evaluation.")

                addSectionCard("Pet First Aid Kit Essentials", R.drawable.ic_first_aid) { layout ->
                    addParagraphToLayout(layout, "Having a dedicated, accessible pet first aid kit is critical for handling acute skin injuries and emergencies.")
                    addParagraphToLayout(layout, "Essential Kit Contents:")
                    addBulletPointToLayout(layout, "Sterile gauze pads, elastic bandage wrap (Vetwrap), non-stick telfa pads, medical tape.")
                    addBulletPointToLayout(layout, "Antiseptic solution (dilute chlorhexidine 0.05% or povidone-iodine) and sterile saline eye/wound wash.")
                    addBulletPointToLayout(layout, "Blunt-ended bandage scissors, fine-tipped tweezers, styptic powder, an e-collar, and emergency vet contacts.")
                }

                addSectionCard("Cuts, Scrapes & Puncture Wounds", R.drawable.ic_bandage) { layout ->
                    addParagraphToLayout(layout, "Open skin wounds compromise the physical barrier, exposing underlying tissues to bacterial infection.")
                    addParagraphToLayout(layout, "First Aid Steps:")
                    addBulletPointToLayout(layout, "Bleeding Control: Apply continuous direct pressure with sterile gauze for 3 to 5 minutes. Do not lift gauze to check.")
                    addBulletPointToLayout(layout, "Wound Flushing: Gently flush superficial scrapes with sterile saline or dilute chlorhexidine. Avoid hydrogen peroxide, which damages healing tissue.")
                    addBulletPointToLayout(layout, "Puncture Warning: Cat bites or deep punctures trap bacteria deep in tissues. All puncture wounds require prompt veterinary care.")
                }

                addSectionCard("Insect Stings & Localized Bites", R.drawable.ic_bug) { layout ->
                    addParagraphToLayout(layout, "Stings from bees, wasps, or insect bites release histamine, causing acute localized swelling and pain.")
                    addParagraphToLayout(layout, "First Aid Steps:")
                    addBulletPointToLayout(layout, "Stinger Removal: Scrape visible bee stingers horizontally with a credit card edge. Avoid tweezers, which squeeze more venom.")
                    addBulletPointToLayout(layout, "Cold Compress: Apply a cold pack wrapped in a cloth for 10 minutes to soothe pain and swelling.")
                    addBulletPointToLayout(layout, "Vet Guidance: Consult your vet before giving antihistamines (diphenhydramine) for exact weight-based dosing.")
                }

                addSectionCard("Hives, Facial Swelling & Anaphylaxis", R.drawable.ic_alert_triangle) { layout ->
                    addParagraphToLayout(layout, "Anaphylaxis is a severe, life-threatening systemic allergic reaction requiring immediate emergency medical care.")
                    addParagraphToLayout(layout, "Critical Warning Signs:")
                    addBulletPointToLayout(layout, "Rapidly spreading hives (urticaria) or sudden, severe facial/muzzle swelling.")
                    addBulletPointToLayout(layout, "Difficulty breathing, wheezing, pale/blue gums, collapse, or violent vomiting.")
                    addBulletPointToLayout(layout, "Emergency Action: Transport your pet immediately to the nearest emergency veterinary facility while keeping them calm.")
                }

                addSectionCard("Thermal Burns & Chemical Contact", R.drawable.ic_water_drop) { layout ->
                    addParagraphToLayout(layout, "Thermal heat or harsh chemical exposure causes rapid coagulation necrosis of skin layers.")
                    addParagraphToLayout(layout, "First Aid Steps:")
                    addBulletPointToLayout(layout, "Thermal Burns: Flush skin with cool running water for 10 minutes. Never apply butter, ice, or ointments, which trap heat.")
                    addBulletPointToLayout(layout, "Chemical Exposure: Flush skin or eyes immediately with generous amounts of lukewarm water or saline for 15 minutes. Seek immediate emergency veterinary care.")
                }
            }
            // Other topics will be added here later
            else -> {
                tvTitle.text = "Topic Not Found"
                addSectionCard("Unavailable", R.drawable.ic_paw) { layout ->
                    addParagraphToLayout(layout, "The content for this topic is currently unavailable.")
                }
            }
        }
    }

    private fun dpToPx(dp: Int): Int {
        return (dp * resources.displayMetrics.density).toInt()
    }

    private fun addIntroBanner(text: String) {
        val banner = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = ContextCompat.getDrawable(context, R.drawable.bg_search_bar)
            backgroundTintList = ColorStateList.valueOf(Color.parseColor("#FFF4E5"))
            setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, dpToPx(24))
            }
            gravity = Gravity.CENTER_VERTICAL
        }

        val icon = ImageView(this).apply {
            setImageResource(R.drawable.ic_paw)
            setColorFilter(Color.parseColor("#FF9800"))
            layoutParams = LinearLayout.LayoutParams(dpToPx(24), dpToPx(24)).apply {
                setMargins(0, 0, dpToPx(12), 0)
            }
        }

        val textView = TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(Color.parseColor("#D98000")) // Darker orange for readable text
            try {
                typeface = ResourcesCompat.getFont(context, R.font.poppins_medium)
            } catch (e: Exception) {
                typeface = Typeface.DEFAULT_BOLD
            }
            setLineSpacing(0f, 1.2f)
        }

        banner.addView(icon)
        banner.addView(textView)
        
        val disclaimerIndex = containerContent.childCount - 1
        containerContent.addView(banner, disclaimerIndex)
    }

    private fun scrollToTargetSection(targetSection: String) {
        containerContent.postDelayed({
            for (i in 0 until containerContent.childCount) {
                val child = containerContent.getChildAt(i)
                if (child is MaterialCardView && child.tag == targetSection) {
                    scrollViewDetail.smoothScrollTo(0, child.top - dpToPx(16))
                    // Subtle purple border highlight animation
                    child.strokeColor = Color.parseColor("#5B2E8F")
                    child.strokeWidth = dpToPx(2)
                    child.postDelayed({
                        child.strokeWidth = 0
                    }, 2500)
                    break
                }
            }
        }, 150)
    }

    private fun addSectionCard(title: String, iconResId: Int, contentSetup: (LinearLayout) -> Unit) {
        val cardView = MaterialCardView(this).apply {
            tag = title
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(dpToPx(4), dpToPx(4), dpToPx(4), dpToPx(24))
            }
            radius = dpToPx(20).toFloat()
            cardElevation = dpToPx(2).toFloat()
            setCardBackgroundColor(Color.WHITE)
            strokeWidth = 0
        }

        val cardInnerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpToPx(20), dpToPx(20), dpToPx(20), dpToPx(8))
        }

        // Header Row (Icon + Title)
        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dpToPx(16))
        }

        val iconContainer = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(dpToPx(40), dpToPx(40)).apply {
                setMargins(0, 0, dpToPx(12), 0)
            }
            background = ContextCompat.getDrawable(context, R.drawable.bg_icon_circle)
            backgroundTintList = ColorStateList.valueOf(Color.parseColor("#F4EEFA"))
        }

        val icon = ImageView(this).apply {
            setImageResource(iconResId)
            setColorFilter(Color.parseColor("#5B2E8F"))
            layoutParams = FrameLayout.LayoutParams(dpToPx(20), dpToPx(20)).apply {
                gravity = Gravity.CENTER
            }
        }
        iconContainer.addView(icon)

        val titleView = TextView(this).apply {
            this.text = title
            textSize = 16f
            setTextColor(Color.parseColor("#2A1B4E"))
            try {
                typeface = ResourcesCompat.getFont(context, R.font.plus_jakarta_sans_bold)
            } catch (e: Exception) {
                typeface = Typeface.DEFAULT_BOLD
            }
        }

        headerRow.addView(iconContainer)
        headerRow.addView(titleView)
        cardInnerLayout.addView(headerRow)

        // Divider
        val divider = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(1)).apply {
                setMargins(0, 0, 0, dpToPx(16))
            }
            setBackgroundColor(Color.parseColor("#F0F0F0"))
        }
        cardInnerLayout.addView(divider)

        // Content
        contentSetup(cardInnerLayout)

        cardView.addView(cardInnerLayout)
        
        val disclaimerIndex = containerContent.childCount - 1
        containerContent.addView(cardView, disclaimerIndex)
    }

    private fun addParagraphToLayout(parent: LinearLayout, text: String) {
        val textView = TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(Color.parseColor("#7C7A8A"))
            try {
                typeface = ResourcesCompat.getFont(context, R.font.poppins_medium)
            } catch (e: Exception) {
                typeface = Typeface.DEFAULT
            }
            setPadding(0, 0, 0, dpToPx(12))
            setLineSpacing(0f, 1.4f)
        }
        parent.addView(textView)
    }

    private fun addBulletPointToLayout(parent: LinearLayout, text: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, dpToPx(12))
        }
        val bulletIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_paw) // Using paw as bullet point
            setColorFilter(Color.parseColor("#8B5FBF"))
            layoutParams = LinearLayout.LayoutParams(dpToPx(14), dpToPx(14)).apply {
                setMargins(0, dpToPx(4), dpToPx(12), 0) // Align with first line of text
            }
        }
        val textView = TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(Color.parseColor("#7C7A8A"))
            try {
                typeface = ResourcesCompat.getFont(context, R.font.poppins_medium)
            } catch (e: Exception) {
                typeface = Typeface.DEFAULT
            }
            setLineSpacing(0f, 1.4f)
        }
        row.addView(bulletIcon)
        row.addView(textView)
        parent.addView(row)
    }
}