package com.example.skinpawsible

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.google.android.material.button.MaterialButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage
import java.io.File
import java.io.FileOutputStream
import java.util.HashMap

class ActivityEditPetProfile : AppCompatActivity() {

    private lateinit var btnBack: ImageButton
    private lateinit var ivPetPhoto: ImageView
    private lateinit var btnChangePhoto: View
    private lateinit var etPetName: EditText
    private lateinit var etPetBreed: EditText
    private lateinit var etPetAge: EditText
    private lateinit var etPetWeight: EditText
    private lateinit var rgGender: RadioGroup
    private lateinit var rbMale: RadioButton
    private lateinit var rbFemale: RadioButton
    private lateinit var btnSavePet: MaterialButton
    private lateinit var btnDeletePet: MaterialButton

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var storage: FirebaseStorage

    private var petId: String? = null
    private var selectedImageUri: Uri? = null
    private var existingImageUrl: String? = null

    private val selectImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            selectedImageUri = uri
            Glide.with(this)
                .load(uri)
                .placeholder(R.drawable.skinpaw)
                .error(R.drawable.skinpaw)
                .into(ivPetPhoto)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_pet_profile)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()
        storage = FirebaseStorage.getInstance()
        petId = intent.getStringExtra("PET_ID")

        if (petId.isNullOrEmpty()) {
            Toast.makeText(this, "Pet not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        initViews()
        setupClickListeners()
        loadExistingPetData()
    }

    private fun initViews() {
        btnBack = findViewById(R.id.btnBack)
        ivPetPhoto = findViewById(R.id.ivPetPhoto)
        btnChangePhoto = findViewById(R.id.btnChangePhoto)
        etPetName = findViewById(R.id.etPetName)
        etPetBreed = findViewById(R.id.etPetBreed)
        etPetAge = findViewById(R.id.etPetAge)
        etPetWeight = findViewById(R.id.etPetWeight)
        rgGender = findViewById(R.id.rgGender)
        rbMale = findViewById(R.id.rbMale)
        rbFemale = findViewById(R.id.rbFemale)
        btnSavePet = findViewById(R.id.btnSavePet)
        btnDeletePet = findViewById(R.id.btnDeletePet)
    }

    private fun setupClickListeners() {
        btnBack.setOnClickListener { finish() }

        val openGallery = {
            selectImageLauncher.launch("image/*")
        }

        ivPetPhoto.setOnClickListener { openGallery() }
        btnChangePhoto.setOnClickListener { openGallery() }

        btnSavePet.setOnClickListener {
            if (validateInputs()) {
                savePetProfileChanges()
            }
        }

        btnDeletePet.setOnClickListener {
            confirmDeletePet()
        }
    }

    private fun loadExistingPetData() {
        val id = petId ?: return

        db.collection("pets").document(id).get()
            .addOnSuccessListener { doc ->
                if (doc != null && doc.exists()) {
                    etPetName.setText(doc.getString("name") ?: "")
                    etPetBreed.setText(doc.getString("breed") ?: "")
                    etPetAge.setText(doc.getString("age") ?: "")
                    etPetWeight.setText(doc.getString("weight") ?: "")

                    existingImageUrl = doc.getString("imageUrl")
                    if (!existingImageUrl.isNullOrEmpty()) {
                        Glide.with(this)
                            .load(existingImageUrl)
                            .placeholder(R.drawable.skinpaw)
                            .error(R.drawable.skinpaw)
                            .into(ivPetPhoto)
                    }

                    val gender = doc.getString("gender") ?: "male"
                    if ("female".equals(gender, ignoreCase = true)) {
                        rbFemale.isChecked = true
                    } else {
                        rbMale.isChecked = true
                    }
                } else {
                    Toast.makeText(this, "Pet document does not exist", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error loading pet details: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun validateInputs(): Boolean {
        if (etPetName.text.isNullOrBlank()) {
            Toast.makeText(this, "Please enter a pet name", Toast.LENGTH_SHORT).show()
            return false
        }
        if (etPetBreed.text.isNullOrBlank()) {
            Toast.makeText(this, "Please enter a breed", Toast.LENGTH_SHORT).show()
            return false
        }
        if (etPetAge.text.isNullOrBlank()) {
            Toast.makeText(this, "Please enter an age", Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }

    private fun saveImageLocally(uri: Uri, petId: String): Uri? {
        return try {
            val inputStream = contentResolver.openInputStream(uri) ?: return null
            val photosDir = File(filesDir, "pet_photos")
            if (!photosDir.exists()) {
                photosDir.mkdirs()
            }
            val photoFile = File(photosDir, "pet_${petId}.jpg")
            val outputStream = FileOutputStream(photoFile)
            inputStream.copyTo(outputStream)
            inputStream.close()
            outputStream.close()
            Uri.fromFile(photoFile)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun savePetProfileChanges() {
        val id = petId ?: return
        btnSavePet.isEnabled = false
        Toast.makeText(this, "Saving changes...", Toast.LENGTH_SHORT).show()

        val imageUri = selectedImageUri
        if (imageUri != null) {
            // Save image to app's internal storage so it is permanently readable across all screens
            val permanentLocalUri = saveImageLocally(imageUri, id) ?: imageUri

            val imageRef = storage.reference.child("pet_images/${id}_${System.currentTimeMillis()}.jpg")
            imageRef.putFile(permanentLocalUri)
                .addOnSuccessListener {
                    imageRef.downloadUrl.addOnSuccessListener { downloadUrl ->
                        updateFirestoreData(id, downloadUrl.toString())
                    }.addOnFailureListener {
                        updateFirestoreData(id, permanentLocalUri.toString())
                    }
                }
                .addOnFailureListener {
                    // Firebase Storage backup fallback -> save permanent local file URI in Firestore
                    updateFirestoreData(id, permanentLocalUri.toString())
                }
        } else {
            updateFirestoreData(id, existingImageUrl)
        }
    }

    private fun updateFirestoreData(id: String, imageUrl: String?) {
        val petName = etPetName.text.toString().trim()
        val breed = etPetBreed.text.toString().trim()
        val age = etPetAge.text.toString().trim()
        val weight = etPetWeight.text.toString().trim()

        val selectedGenderId = rgGender.checkedRadioButtonId
        val gender = if (selectedGenderId == R.id.rbFemale) "female" else "male"

        val updateData = HashMap<String, Any>()
        updateData["name"] = petName
        updateData["breed"] = breed
        updateData["age"] = age
        updateData["weight"] = weight
        updateData["gender"] = gender
        if (!imageUrl.isNullOrEmpty()) {
            updateData["imageUrl"] = imageUrl
        }
        updateData["updatedAt"] = FieldValue.serverTimestamp()

        db.collection("pets").document(id)
            .set(updateData, SetOptions.merge())
            .addOnSuccessListener {
                Toast.makeText(this, "$petName's profile updated!", Toast.LENGTH_SHORT).show()
                finish()
            }
            .addOnFailureListener { e ->
                btnSavePet.isEnabled = true
                Toast.makeText(this, "Failed to update: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun confirmDeletePet() {
        val petName = etPetName.text.toString().ifBlank { "this pet" }
        AlertDialog.Builder(this)
            .setTitle("Delete Pet Profile")
            .setMessage("Are you sure you want to delete $petName's profile? This action cannot be undone.")
            .setPositiveButton("Delete") { _, _ ->
                deletePetProfile()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun deletePetProfile() {
        val id = petId ?: return
        btnDeletePet.isEnabled = false

        db.collection("pets").document(id).delete()
            .addOnSuccessListener {
                Toast.makeText(this, "Pet profile deleted", Toast.LENGTH_SHORT).show()
                finish()
            }
            .addOnFailureListener { e ->
                btnDeletePet.isEnabled = true
                Toast.makeText(this, "Error deleting pet: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}
