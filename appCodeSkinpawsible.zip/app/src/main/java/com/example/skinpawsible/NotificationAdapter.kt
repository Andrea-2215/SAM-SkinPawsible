package com.example.skinpawsible

import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView

sealed class NotificationListItem {
    data class Header(val title: String) : NotificationListItem()
    data class Item(val notification: NotificationItem) : NotificationListItem()
}

class NotificationAdapter(
    private var displayList: MutableList<NotificationListItem>,
    private val onNotificationClicked: (NotificationItem) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val TYPE_HEADER = 0
        private const val TYPE_ITEM = 1
    }

    class HeaderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvHeaderTitle: TextView = itemView.findViewById(R.id.tvHeaderTitle)
    }

    class NotificationViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val cardNotification: MaterialCardView = itemView.findViewById(R.id.cardNotification)
        val vUnreadDot: View = itemView.findViewById(R.id.vUnreadDot)
        val flNotificationIconBg: FrameLayout = itemView.findViewById(R.id.flNotificationIconBg)
        val ivNotificationIcon: ImageView = itemView.findViewById(R.id.ivNotificationIcon)
        val tvNotificationTitle: TextView = itemView.findViewById(R.id.tvNotificationTitle)
        val tvNotificationMessage: TextView = itemView.findViewById(R.id.tvNotificationMessage)
        val tvNotificationTime: TextView = itemView.findViewById(R.id.tvNotificationTime)
    }

    override fun getItemViewType(position: Int): Int {
        return when (displayList[position]) {
            is NotificationListItem.Header -> TYPE_HEADER
            is NotificationListItem.Item -> TYPE_ITEM
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == TYPE_HEADER) {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_notification_header, parent, false)
            HeaderViewHolder(view)
        } else {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_notification, parent, false)
            NotificationViewHolder(view)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val item = displayList[position]) {
            is NotificationListItem.Header -> {
                val headerHolder = holder as HeaderViewHolder
                headerHolder.tvHeaderTitle.text = item.title
            }
            is NotificationListItem.Item -> {
                val notifHolder = holder as NotificationViewHolder
                val notif = item.notification

                notifHolder.tvNotificationTitle.text = notif.title
                notifHolder.tvNotificationMessage.text = notif.message
                notifHolder.tvNotificationTime.text = notif.getFormattedTime()

                // Icon & Color Tint
                notifHolder.ivNotificationIcon.setImageResource(notif.type.iconRes)
                notifHolder.ivNotificationIcon.imageTintList = ColorStateList.valueOf(notif.type.iconTintHex.toInt())
                notifHolder.flNotificationIconBg.backgroundTintList = ColorStateList.valueOf(notif.type.bgColorHex.toInt())

                // Read/Unread State
                if (notif.isRead) {
                    notifHolder.vUnreadDot.visibility = View.GONE
                    notifHolder.cardNotification.setCardBackgroundColor(Color.parseColor("#FFFFFF"))
                } else {
                    notifHolder.vUnreadDot.visibility = View.VISIBLE
                    notifHolder.cardNotification.setCardBackgroundColor(Color.parseColor("#F7F2FA"))
                }

                notifHolder.cardNotification.setOnClickListener {
                    notif.isRead = true
                    notifyItemChanged(holder.adapterPosition)
                    onNotificationClicked(notif)
                }
            }
        }
    }

    override fun getItemCount(): Int = displayList.size

    fun getNotificationAt(position: Int): NotificationItem? {
        if (position < 0 || position >= displayList.size) return null
        val listItem = displayList[position]
        return if (listItem is NotificationListItem.Item) listItem.notification else null
    }

    fun updateDisplayList(newList: List<NotificationListItem>) {
        displayList = newList.toMutableList()
        notifyDataSetChanged()
    }
}
