package com.example.skinpawsible

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.bumptech.glide.Glide
import com.google.android.material.button.MaterialButton
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore

class ActivityScanResults : BaseActivity() {

    private lateinit var imgScannedPet: ImageView
    private lateinit var tvConditionTitle: TextView
    private lateinit var tvConfidenceLevel: TextView
    private lateinit var tvConfidencePercentage: TextView
    private lateinit var progressConfidence: LinearProgressIndicator
    private lateinit var imgConditionBadge: ImageView
    private lateinit var tvAboutHeader: TextView
    private lateinit var tvConditionDescription: TextView
    private lateinit var containerRecommendations: LinearLayout
    private lateinit var btnViewManual: MaterialButton
    private lateinit var btnConsultVet: MaterialButton
    private lateinit var btnBack: ImageButton

    // Post-Scan Tagging UI Components
    private lateinit var autoCompletePetSelector: AutoCompleteTextView
    private lateinit var btnAddPetPrompt: TextView

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scan_results)

        initViews()
        setupPetSelector()

        // Check if opened from History or a Fresh Scan
        val isFromHistory = intent.getBooleanExtra("IS_FROM_HISTORY", false)

        if (isFromHistory) {
            // Unpack data passed from HistoryAdapter / ActivityHistory
            val condition = intent.getStringExtra("EXTRA_CONDITION") ?: "Healthy"
            val confidenceStr = intent.getStringExtra("EXTRA_CONFIDENCE") ?: "0%"
            val imageUrl = intent.getStringExtra("EXTRA_IMAGE_URL") ?: ""

            // Parse numeric score from "85%" string format
            val scoreVal = (confidenceStr.replace("%", "").toFloatOrNull() ?: 0f) / 100f

            if (imageUrl.isNotEmpty()) {
                Glide.with(this).load(imageUrl).into(imgScannedPet)
            }

            displayDynamicResult(condition, scoreVal)
            // History scans don't re-save to Firestore
        } else {
            // Receive inputs from live scan operation
            val conditionKey = intent.getStringExtra("EXTRA_CONDITION_KEY") ?: "other"
            val confidenceScore = intent.getFloatExtra("EXTRA_CONFIDENCE_SCORE", 0.0f)
            val imageUriString = intent.getStringExtra("EXTRA_IMAGE_URI") ?: ""
            val petName = intent.getStringExtra("EXTRA_PET_NAME") ?: "Pet"

            if (imageUriString.isNotEmpty()) {
                Glide.with(this).load(imageUriString).into(imgScannedPet)
            }

            displayDynamicResult(conditionKey, confidenceScore)
            saveScanToFirestore(petName, conditionKey, confidenceScore, imageUriString)
        }

        // Navigation handlers
        btnBack.setOnClickListener {
            finish()
        }

        btnViewManual.setOnClickListener {
            startActivity(Intent(this, ActivityPetCareManual::class.java))
        }

        btnConsultVet.setOnClickListener {
            val intent = Intent(this, ActivityConsultVet::class.java).apply {
                putExtra("EXTRA_CONDITION_CONTEXT", tvConditionTitle.text.toString())
            }
            startActivity(intent)
        }

        // Add Pet Prompt Handler
        btnAddPetPrompt.setOnClickListener {
            openMyPetsActivityToAddPet()
        }
    }

    private fun initViews() {
        imgScannedPet = findViewById(R.id.imgScannedPet)
        tvConditionTitle = findViewById(R.id.tvConditionTitle)
        tvConfidenceLevel = findViewById(R.id.tvConfidenceLevel)
        tvConfidencePercentage = findViewById(R.id.tvConfidencePercentage)
        progressConfidence = findViewById(R.id.progressConfidence)
        imgConditionBadge = findViewById(R.id.imgConditionBadge)
        tvAboutHeader = findViewById(R.id.tvAboutHeader)
        tvConditionDescription = findViewById(R.id.tvConditionDescription)
        containerRecommendations = findViewById(R.id.containerRecommendations)
        btnViewManual = findViewById(R.id.btnViewManual)
        btnConsultVet = findViewById(R.id.btnConsultVet)
        btnBack = findViewById(R.id.btnBack)

        autoCompletePetSelector = findViewById(R.id.autoCompletePetSelector)
        btnAddPetPrompt = findViewById(R.id.btnAddPetPrompt)
    }

    private fun setupPetSelector() {
        val userId = auth.currentUser?.uid ?: return

        // Fetch user's registered pets from Firestore
        db.collection("users")
            .document(userId)
            .collection("pets")
            .get()
            .addOnSuccessListener { querySnapshot ->
                val petNames = mutableListOf<String>()
                for (doc in querySnapshot) {
                    val name = doc.getString("name") ?: doc.getString("petName")
                    if (!name.isNullOrEmpty()) {
                        petNames.add(name)
                    }
                }

                // Add prompt item inside dropdown
                petNames.add("+ Add New Pet")

                val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, petNames)
                autoCompletePetSelector.setAdapter(adapter)

                // Pre-fill selector if passed from scan extra
                val passedPetName = intent.getStringExtra("EXTRA_PET_NAME")
                if (!passedPetName.isNullOrEmpty() && passedPetName != "Pet") {
                    autoCompletePetSelector.setText(passedPetName, false)
                }

                autoCompletePetSelector.setOnItemClickListener { _, _, position, _ ->
                    val selected = adapter.getItem(position)
                    if (selected == "+ Add New Pet") {
                        autoCompletePetSelector.setText("", false)
                        openMyPetsActivityToAddPet()
                    }
                }
            }
            .addOnFailureListener {
                // Fallback option in case of network issue
                val fallbackList = listOf("+ Add New Pet")
                val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, fallbackList)
                autoCompletePetSelector.setAdapter(adapter)
            }
    }

    private fun openMyPetsActivityToAddPet() {
        val intent = Intent(this, ActivityMyPets::class.java).apply {
            putExtra("EXTRA_OPEN_ADD_PET", true)
        }
        startActivity(intent)
    }

    private fun displayDynamicResult(conditionKey: String, score: Float) {
        val scorePercent = (score * 100).toInt()
        tvConfidencePercentage.text = "$scorePercent%"
        progressConfidence.progress = scorePercent

        tvConfidenceLevel.text = when {
            score >= 0.80f -> "(High Confidence)"
            score >= 0.50f -> "(Medium Confidence)"
            else -> "(Low Confidence - Consult Vet)"
        }

        when (conditionKey.lowercase().trim()) {
            "healthy", "healthy skin" -> updateUI(
                title = "Healthy Skin",
                description = "No obvious signs of fungal infection or abnormal skin lesions were detected on the scanned area.",
                badgeRes = R.drawable.ic_healthy_badge,
                recommendations = listOf(
                    "Maintain routine grooming and bathing schedules",
                    "Keep coat dry and perform regular physical skin checks"
                )
            )
            "ringworm" -> updateUI(
                title = "Ringworm",
                description = "Ringworm is a fungal infection that affects the skin, causing circular, scaly patches and hair loss.",
                badgeRes = R.drawable.ic_ringworm_badge,
                recommendations = listOf(
                    "Topical antifungal medication",
                    "Regularly clean and sanitize the affected area",
                    "Isolate from other pets to prevent spread",
                    "Consult a veterinarian for an accurate prescription"
                )
            )
            "yeast", "yeast infection" -> updateUI(
                title = "Yeast Infection",
                description = "Yeast dermatitis occurs when normal skin fungi overgrow in warm, moist areas, leading to redness, itching, and odor.",
                badgeRes = R.drawable.ic_yeast_badge,
                recommendations = listOf(
                    "Keep the affected skin fold dry and clean",
                    "Use medicated anti-fungal wipes or shampoo",
                    "Prevent the pet from excessive licking or biting"
                )
            )
            else -> updateUI(
                title = "Uncertain / Other Condition",
                description = "The AI model could not identify a definitive match for this scan. Please speak directly with a licensed veterinarian.",
                badgeRes = R.drawable.ic_consult_badge,
                recommendations = listOf(
                    "Schedule a direct consultation with a licensed vet",
                    "Avoid applying unverified home treatments",
                    "Keep the area clean and unexposed"
                )
            )
        }
    }

    private fun updateUI(title: String, description: String, badgeRes: Int, recommendations: List<String>) {
        tvConditionTitle.text = title
        tvAboutHeader.text = "About $title"
        tvConditionDescription.text = description
        imgConditionBadge.setImageResource(badgeRes)

        containerRecommendations.removeAllViews()
        for (step in recommendations) {
            val tv = TextView(this).apply {
                text = "•  $step"
                textSize = 13f
                setTextColor(android.graphics.Color.parseColor("#4E4A67"))
                setPadding(0, 4, 0, 4)
            }
            containerRecommendations.addView(tv)
        }
    }

    private fun saveScanToFirestore(petName: String, conditionKey: String, score: Float, imageUrl: String) {
        val userId = auth.currentUser?.uid ?: return

        val sdf = java.text.SimpleDateFormat("MMM dd, yyyy", java.util.Locale.getDefault())
        val dateString = sdf.format(java.util.Date())

        val scanRecord = hashMapOf(
            "userId" to userId,
            "petName" to petName,
            "result" to conditionKey,
            "confidence" to "${(score * 100).toInt()}%",
            "date" to dateString,
            "imageUrl" to imageUrl,
            "timestamp" to FieldValue.serverTimestamp()
        )

        db.collection("users")
            .document(userId)
            .collection("scans")
            .add(scanRecord)
            .addOnFailureListener { e ->
                Toast.makeText(this, "Failed to sync history: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
    }
}