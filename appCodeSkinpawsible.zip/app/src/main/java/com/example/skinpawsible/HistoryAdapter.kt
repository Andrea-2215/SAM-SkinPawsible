package com.example.skinpawsible

import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class HistoryAdapter(
    private val scanList: List<ScanRecord>,
    private val onItemClick: (ScanRecord) -> Unit
) : RecyclerView.Adapter<HistoryAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTitle: TextView = view.findViewById(R.id.tvConditionTitle)
        val tvConfidence: TextView = view.findViewById(R.id.tvConfidenceBadge)
        val tvDate: TextView = view.findViewById(R.id.tvScanDate)
        val imgThumbnail: ImageView = view.findViewById(R.id.imgScanThumbnail)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_history_card, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = scanList[position]
        holder.tvTitle.text = item.result
        holder.tvDate.text = item.date

        // Parse numerical score for confidence styling
        val scoreVal = item.confidence.replace("%", "").toDoubleOrNull() ?: 0.0

        // Apply High, Mid, or Low confidence badge colors
        when {
            scoreVal >= 80 -> {
                holder.tvConfidence.text = "${scoreVal.toInt()}% High Confidence"
                holder.tvConfidence.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#F0EBFC"))
                holder.tvConfidence.setTextColor(Color.parseColor("#5B2E8F"))
            }
            scoreVal >= 50 -> {
                holder.tvConfidence.text = "${scoreVal.toInt()}% Mid Confidence"
                holder.tvConfidence.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#FFF3E0"))
                holder.tvConfidence.setTextColor(Color.parseColor("#E65100"))
            }
            else -> {
                holder.tvConfidence.text = "${scoreVal.toInt()}% Low Confidence"
                holder.tvConfidence.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#FFEBEE"))
                holder.tvConfidence.setTextColor(Color.parseColor("#C62828"))
            }
        }

        // Image loading with fallback icon reset
        if (!item.imageUrl.isNullOrEmpty()) {
            holder.imgThumbnail.setPadding(0, 0, 0, 0)
            holder.imgThumbnail.imageTintList = null
            Glide.with(holder.itemView.context)
                .load(item.imageUrl)
                .into(holder.imgThumbnail)
        } else {
            holder.imgThumbnail.setPadding(16, 16, 16, 16)
            holder.imgThumbnail.setImageResource(R.drawable.ic_camera)
            holder.imgThumbnail.imageTintList = ColorStateList.valueOf(Color.parseColor("#5B2E8F"))
        }

        // Trigger item click callback
        holder.itemView.setOnClickListener {
            onItemClick(item)
        }
    }

    override fun getItemCount(): Int = scanList.size
}