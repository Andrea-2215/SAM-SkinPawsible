package com.example.skinpawsible;

import android.os.Bundle;
import android.util.Patterns;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;

public class ForgotPassword extends BaseActivity {

    private ImageButton btnBack;
    private TextInputEditText etEmail;
    private TextInputLayout tilEmail;
    private MaterialButton btnSendOtp;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        mAuth = FirebaseAuth.getInstance();

        btnBack = findViewById(R.id.btnBack);
        etEmail = findViewById(R.id.etEmail);
        tilEmail = findViewById(R.id.tilEmail);
        btnSendOtp = findViewById(R.id.btnSendOtp);

        btnBack.setOnClickListener(v -> finish());

        btnSendOtp.setOnClickListener(v -> handlePasswordReset());
    }

    private void handlePasswordReset() {
        String email = etEmail.getText() != null ? etEmail.getText().toString().trim() : "";
        tilEmail.setError(null);

        if (email.isEmpty()) {
            tilEmail.setError("Please enter your email address");
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            tilEmail.setError("Please enter a valid email address");
            return;
        }

        btnSendOtp.setEnabled(false);
        Toast.makeText(this, "Sending reset email...", Toast.LENGTH_SHORT).show();

        // Send reset email via Firebase Authentication
        mAuth.sendPasswordResetEmail(email)
                .addOnCompleteListener(task -> {
                    btnSendOtp.setEnabled(true);
                    if (task.isSuccessful()) {
                        Toast.makeText(ForgotPassword.this,
                                "Password reset link sent to " + email,
                                Toast.LENGTH_LONG).show();
                        finish(); // Return to Login Screen
                    } else {
                        String error = task.getException() != null ?
                                task.getException().getMessage() : "Failed to send email.";
                        Toast.makeText(ForgotPassword.this, "Error: " + error, Toast.LENGTH_SHORT).show();
                    }
                });
    }
}