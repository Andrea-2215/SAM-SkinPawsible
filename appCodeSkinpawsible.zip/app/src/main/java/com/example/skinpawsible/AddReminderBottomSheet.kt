package com.example.skinpawsible

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.ContextThemeWrapper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class AddReminderBottomSheet(
    private val editingItem: ReminderItem? = null,
    private val onSaveCallback: (ReminderItem) -> Unit
) : BottomSheetDialogFragment() {

    private var selectedPet: String = "Pet"
    private var selectedCategory: ReminderCategory = ReminderCategory.BATH
    private var selectedDateText: String = "Today"
    private var selectedTimeText: String = "5:00 PM"
    private var selectedRepeatText: String = "Every 3 days"

    private val calendar = Calendar.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.bottom_sheet_add_reminder, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val tvTitle = view.findViewById<TextView>(R.id.tvBottomSheetTitle)
        val btnClose = view.findViewById<ImageView>(R.id.btnCloseBottomSheet)
        val cgPet = view.findViewById<ChipGroup>(R.id.cgSelectPet)
        val etTitle = view.findViewById<EditText>(R.id.etReminderTitle)
        val cgCategory = view.findViewById<ChipGroup>(R.id.cgSelectCategory)
        val btnDate = view.findViewById<MaterialButton>(R.id.btnSelectDate)
        val btnTime = view.findViewById<MaterialButton>(R.id.btnSelectTime)
        val cgRepeat = view.findViewById<ChipGroup>(R.id.cgSelectRepeat)
        val etNotes = view.findViewById<EditText>(R.id.etReminderNotes)
        val btnSave = view.findViewById<MaterialButton>(R.id.btnSaveReminder)

        btnClose.setOnClickListener { dismiss() }

        // Date Picker Trigger
        btnDate.text = selectedDateText
        btnDate.setOnClickListener {
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)

            val dpd = DatePickerDialog(requireContext(), { _, y, m, d ->
                calendar.set(Calendar.YEAR, y)
                calendar.set(Calendar.MONTH, m)
                calendar.set(Calendar.DAY_OF_MONTH, d)
                val sdf = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
                selectedDateText = sdf.format(calendar.time)
                btnDate.text = selectedDateText
            }, year, month, day)
            dpd.show()
        }

        // Time Picker Trigger
        btnTime.text = selectedTimeText
        btnTime.setOnClickListener {
            val hour = calendar.get(Calendar.HOUR_OF_DAY)
            val minute = calendar.get(Calendar.MINUTE)

            val tpd = TimePickerDialog(requireContext(), { _, h, m ->
                val isPm = h >= 12
                val hour12 = if (h % 12 == 0) 12 else h % 12
                val minuteStr = String.format(Locale.getDefault(), "%02d", m)
                val amPmStr = if (isPm) "PM" else "AM"
                selectedTimeText = "$hour12:$minuteStr $amPmStr"
                btnTime.text = selectedTimeText
            }, hour, minute, false)
            tpd.show()
        }

        // Fetch User's Pets from Firestore
        val currentUser = FirebaseAuth.getInstance().currentUser
        if (currentUser != null) {
            FirebaseFirestore.getInstance().collection("pets")
                .whereEqualTo("ownerId", currentUser.uid)
                .get()
                .addOnSuccessListener { snapshots ->
                    if (snapshots != null && !snapshots.isEmpty) {
                        cgPet.removeAllViews()
                        var isFirst = true
                        val contextWrapper = ContextThemeWrapper(requireContext(), com.google.android.material.R.style.Widget_Material3_Chip_Filter)
                        for (doc in snapshots.documents) {
                            val name = doc.getString("name") ?: continue
                            val chip = Chip(contextWrapper, null, com.google.android.material.R.style.Widget_Material3_Chip_Filter).apply {
                                text = name
                                isCheckable = true
                                isClickable = true
                                isCheckedIconVisible = false
                                isChecked = isFirst || (editingItem != null && editingItem.petName.equals(name, ignoreCase = true))
                                textSize = 12f
                                chipMinHeight = 36f
                                chipStartPadding = 10f
                                chipEndPadding = 10f
                                chipStrokeWidth = 0f
                                chipBackgroundColor = ContextCompat.getColorStateList(requireContext(), R.color.chip_background_selector)
                                setTextColor(ContextCompat.getColorStateList(requireContext(), R.color.chip_text_selector))
                            }
                            if (chip.isChecked) {
                                selectedPet = name
                            }
                            cgPet.addView(chip)
                            isFirst = false
                        }
                    }
                }
        }

        // Pet Selection Listener
        cgPet.setOnCheckedStateChangeListener { group, checkedIds ->
            if (checkedIds.isNotEmpty()) {
                val chip = group.findViewById<Chip>(checkedIds[0])
                if (chip != null) {
                    selectedPet = chip.text.toString()
                }
            }
        }

        // Category Selection Chip Group
        cgCategory.setOnCheckedStateChangeListener { _, checkedIds ->
            selectedCategory = when {
                checkedIds.contains(R.id.chipSelectMed) -> ReminderCategory.MEDICATION
                checkedIds.contains(R.id.chipSelectVet) -> ReminderCategory.VET_VISIT
                checkedIds.contains(R.id.chipSelectDiet) -> ReminderCategory.DIET
                else -> ReminderCategory.BATH
            }
        }

        // Repeat Selection Chip Group
        cgRepeat.setOnCheckedStateChangeListener { _, checkedIds ->
            selectedRepeatText = when {
                checkedIds.contains(R.id.chipRepeatOnce) -> "Once"
                checkedIds.contains(R.id.chipRepeatDaily) -> "Daily"
                checkedIds.contains(R.id.chipRepeatWeekly) -> "Weekly"
                else -> "Every 3 days"
            }
        }

        // Pre-fill if editing existing item
        if (editingItem != null) {
            tvTitle.text = "Edit Care Reminder"
            btnSave.text = "Update Reminder"

            etTitle.setText(editingItem.title)
            etNotes.setText(editingItem.notes)
            selectedPet = editingItem.petName

            // Parse Date and Time from dateTimeText (e.g. "Sep 12, 2026 at 10:00 AM" or "Today at 5:00 PM")
            val dt = editingItem.dateTimeText
            if (dt.contains(" at ", ignoreCase = true)) {
                val parts = dt.split(" at ", " AT ", " At ")
                if (parts.size >= 2) {
                    selectedDateText = parts[0].trim()
                    selectedTimeText = parts[1].trim()
                }
            } else {
                selectedDateText = dt
            }
            btnDate.text = selectedDateText
            btnTime.text = selectedTimeText

            // Parse calendar instance for DatePicker & TimePicker triggers
            try {
                val fullStr = "$selectedDateText at $selectedTimeText"
                val cleanStr = if (fullStr.contains("Today", ignoreCase = true)) {
                    val todayStr = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Calendar.getInstance().time)
                    fullStr.replace("Today", todayStr, ignoreCase = true)
                } else {
                    fullStr
                }
                val sdf = SimpleDateFormat("MMM dd, yyyy 'at' h:mm a", Locale.getDefault())
                val parsedDate = sdf.parse(cleanStr)
                if (parsedDate != null) {
                    calendar.time = parsedDate
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            selectedCategory = editingItem.category
            when (editingItem.category) {
                ReminderCategory.MEDICATION -> cgCategory.check(R.id.chipSelectMed)
                ReminderCategory.VET_VISIT -> cgCategory.check(R.id.chipSelectVet)
                ReminderCategory.DIET -> cgCategory.check(R.id.chipSelectDiet)
                else -> cgCategory.check(R.id.chipSelectBath)
            }

            selectedRepeatText = editingItem.repeatText
            when (editingItem.repeatText) {
                "Once" -> cgRepeat.check(R.id.chipRepeatOnce)
                "Daily" -> cgRepeat.check(R.id.chipRepeatDaily)
                "Weekly" -> cgRepeat.check(R.id.chipRepeatWeekly)
                else -> cgRepeat.check(R.id.chipRepeat3Days)
            }
        }

        // Save Action
        btnSave.setOnClickListener {
            val titleText = etTitle.text.toString().trim()
            if (titleText.isEmpty()) {
                Toast.makeText(requireContext(), "Please enter a title for the reminder", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val notesText = etNotes.text.toString().trim()
            val dateTimeCombined = "$selectedDateText at $selectedTimeText"

            val resultItem = editingItem?.copy(
                petName = selectedPet,
                title = titleText,
                category = selectedCategory,
                dateTimeText = dateTimeCombined,
                repeatText = selectedRepeatText,
                notes = notesText
            ) ?: ReminderItem(
                petName = selectedPet,
                title = titleText,
                category = selectedCategory,
                dateTimeText = dateTimeCombined,
                repeatText = selectedRepeatText,
                notes = notesText
            )

            onSaveCallback(resultItem)
            dismiss()
        }
    }
}
