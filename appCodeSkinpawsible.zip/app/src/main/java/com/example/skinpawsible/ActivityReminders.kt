package com.example.skinpawsible

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.ContextThemeWrapper
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class ActivityReminders : BaseActivity() {

    private lateinit var rvReminders: RecyclerView
    private lateinit var llEmptyState: LinearLayout
    private lateinit var chipGroupPet: ChipGroup
    private lateinit var chipGroupCategory: ChipGroup
    private lateinit var adapter: ReminderAdapter

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private var remindersListener: ListenerRegistration? = null
    private var petsListener: ListenerRegistration? = null

    private val allReminders = mutableListOf<ReminderItem>()
    private var userPetNames = mutableListOf<String>()
    private var selectedPetFilter: String = "ALL"
    private var selectedCategoryFilter: ReminderCategory? = null
    private var isCompletedSectionExpanded: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reminders)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        checkNotificationPermission()

        // Header Controls
        val btnBack = findViewById<ImageView>(R.id.btnBack)
        btnBack?.setOnClickListener { finish() }

        val btnAddReminder = findViewById<ImageButton>(R.id.btnAddReminder)
        btnAddReminder?.setOnClickListener {
            val addSheet = AddReminderBottomSheet { newItem ->
                saveReminderToFirestore(newItem)
            }
            addSheet.show(supportFragmentManager, "AddReminderBottomSheet")
        }

        // Views
        rvReminders = findViewById(R.id.rvReminders)
        llEmptyState = findViewById(R.id.llEmptyState)
        chipGroupPet = findViewById(R.id.chipGroupPet)
        chipGroupCategory = findViewById(R.id.chipGroupCategory)

        // Setup RecyclerView
        rvReminders.layoutManager = LinearLayoutManager(this)

        adapter = ReminderAdapter(
            displayList = getGroupedReminderDisplayList().toMutableList(),
            onItemClicked = { item ->
                val editSheet = AddReminderBottomSheet(editingItem = item) { updatedItem ->
                    saveReminderToFirestore(updatedItem)
                }
                editSheet.show(supportFragmentManager, "EditReminderBottomSheet")
            },
            onToggleChanged = { item, isEnabled ->
                db.collection("reminders").document(item.id)
                    .update("isEnabled", isEnabled)
            },
            onMarkDoneClicked = { item ->
                db.collection("reminders").document(item.id)
                    .update("isCompleted", item.isCompleted)
                applyFilters()
            },
            onDeleteClicked = { item ->
                db.collection("reminders").document(item.id).delete()
                    .addOnSuccessListener {
                        Toast.makeText(this, "Reminder deleted", Toast.LENGTH_SHORT).show()
                    }
            },
            onCompletedHeaderClicked = {
                isCompletedSectionExpanded = !isCompletedSectionExpanded
                applyFilters()
            }
        )
        rvReminders.adapter = adapter

        setupFilterListeners()
    }

    override fun onStart() {
        super.onStart()
        listenToUserPets()
        listenToReminders()
    }

    override fun onStop() {
        super.onStop()
        remindersListener?.remove()
        petsListener?.remove()
    }

    private fun checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }
    }

    private fun parseDateTimeToMillis(dateTimeStr: String): Long {
        return try {
            val todayStr = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Calendar.getInstance().time)
            val cleanStr = if (dateTimeStr.contains("Today at ", ignoreCase = true)) {
                dateTimeStr.replace("Today at ", "$todayStr at ", ignoreCase = true)
            } else {
                dateTimeStr
            }
            val sdf = SimpleDateFormat("MMM dd, yyyy 'at' h:mm a", Locale.getDefault())
            sdf.parse(cleanStr)?.time ?: (System.currentTimeMillis() + 60_000L)
        } catch (e: Exception) {
            System.currentTimeMillis() + 60_000L
        }
    }

    private fun isDateToday(dateTimeStr: String): Boolean {
        if (dateTimeStr.contains("Today", ignoreCase = true)) return true
        val todayStr = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Calendar.getInstance().time)
        return dateTimeStr.contains(todayStr, ignoreCase = true)
    }

    private fun saveReminderToFirestore(item: ReminderItem) {
        val currentUserId = auth.currentUser?.uid
        if (currentUserId.isNullOrEmpty()) {
            Toast.makeText(this, "Please log in to save reminders", Toast.LENGTH_SHORT).show()
            return
        }
        val itemWithUser = item.copy(userId = currentUserId)

        db.collection("reminders").document(itemWithUser.id)
            .set(itemWithUser.toMap())
            .addOnSuccessListener {
                Toast.makeText(this, "Reminder '${itemWithUser.title}' saved!", Toast.LENGTH_SHORT).show()

                // ONLY create an immediate Notification & Status Bar Alert IF created/prescribed by a VET!
                if (itemWithUser.isVetPrescribed) {
                    val notifTitle = "Vet Appointment / Prescription Added"
                    val notifMessage = "Dr. ${itemWithUser.createdBy} added '${itemWithUser.title}' for ${itemWithUser.petName} (${itemWithUser.dateTimeText})."

                    // 1. Write Notification to Firestore
                    val notifItem = NotificationItem(
                        userId = currentUserId,
                        title = notifTitle,
                        message = notifMessage,
                        timestamp = "Just now",
                        type = NotificationType.VET_UPDATE,
                        targetScreen = "REMINDER",
                        targetId = itemWithUser.title,
                        isRead = false
                    )
                    db.collection("notifications").document(notifItem.id)
                        .set(notifItem.toMap())

                    // 2. Trigger System Status Bar Alert for Vet creation
                    val targetIntent = Intent(this, ActivityNotifications::class.java)
                    ReminderNotificationHelper.showSystemNotification(
                        context = this,
                        title = notifTitle,
                        message = notifMessage,
                        targetIntent = targetIntent
                    )
                }

                // Schedule background Exact Alarms:
                val targetMillis = parseDateTimeToMillis(itemWithUser.dateTimeText)
                val currentTime = System.currentTimeMillis()
                val oneHourMillis = 3_600_000L

                // 1. If event is > 1 hour away -> Schedule 1-Hour Pre-Alert ("Upcoming Care Reminder")
                if (targetMillis - oneHourMillis > currentTime) {
                    ReminderNotificationHelper.scheduleExactAlarm(
                        context = this,
                        title = "Upcoming Care Reminder",
                        message = "Heads-up! ${itemWithUser.petName}'s ${itemWithUser.title} is coming up in 1 hour (${itemWithUser.dateTimeText}).",
                        alarmTriggerMillis = targetMillis - oneHourMillis
                    )
                }

                // 2. Schedule Exact-Time Alert ("Care Reminder Due Now!")
                val exactTrigger = if (targetMillis > currentTime) targetMillis else currentTime + 5_000L
                ReminderNotificationHelper.scheduleExactAlarm(
                    context = this,
                    title = "Care Reminder Due Now!",
                    message = "It's time! ${itemWithUser.petName}'s ${itemWithUser.title} is scheduled for right now (${itemWithUser.dateTimeText}).",
                    alarmTriggerMillis = exactTrigger
                )
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Failed to save: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun listenToReminders() {
        val currentUser = auth.currentUser ?: return

        remindersListener?.remove()
        remindersListener = db.collection("reminders")
            .whereEqualTo("userId", currentUser.uid)
            .addSnapshotListener { snapshots, error ->
                if (error != null) {
                    Toast.makeText(this, "Failed to load reminders: ${error.message}", Toast.LENGTH_SHORT).show()
                    return@addSnapshotListener
                }

                allReminders.clear()
                if (snapshots != null && !snapshots.isEmpty) {
                    for (doc in snapshots.documents) {
                        allReminders.add(ReminderItem.fromDocument(doc))
                    }
                }
                applyFilters()
            }
    }

    private fun listenToUserPets() {
        val currentUser = auth.currentUser ?: return

        petsListener?.remove()
        petsListener = db.collection("pets")
            .whereEqualTo("ownerId", currentUser.uid)
            .addSnapshotListener { snapshots, _ ->
                userPetNames.clear()
                if (snapshots != null && !snapshots.isEmpty) {
                    for (doc in snapshots.documents) {
                        val name = doc.getString("name")
                        if (!name.isNullOrBlank()) {
                            userPetNames.add(name)
                        }
                    }
                }
                rebuildPetFilterChips()
            }
    }

    private fun rebuildPetFilterChips() {
        chipGroupPet.removeAllViews()

        val contextWrapper = ContextThemeWrapper(this, com.google.android.material.R.style.Widget_Material3_Chip_Filter)

        // "My Pets" Chip
        val chipAll = Chip(contextWrapper, null, com.google.android.material.R.style.Widget_Material3_Chip_Filter).apply {
            id = R.id.chipPetAll
            text = "My Pets"
            isCheckable = true
            isClickable = true
            isCheckedIconVisible = false
            isChecked = selectedPetFilter == "ALL"
            textSize = 12f
            chipMinHeight = 36f
            chipStartPadding = 14f
            chipEndPadding = 14f
            chipStrokeWidth = 0f
            chipBackgroundColor = ContextCompat.getColorStateList(this@ActivityReminders, R.color.chip_background_selector)
            setTextColor(ContextCompat.getColorStateList(this@ActivityReminders, R.color.chip_text_selector))
        }
        chipGroupPet.addView(chipAll)

        // Dynamic Pet Chips from Firestore (Text Only)
        for (petName in userPetNames) {
            val petChip = Chip(contextWrapper, null, com.google.android.material.R.style.Widget_Material3_Chip_Filter).apply {
                text = petName
                isCheckable = true
                isClickable = true
                isCheckedIconVisible = false
                isChecked = selectedPetFilter.equals(petName, ignoreCase = true)
                textSize = 12f
                chipMinHeight = 36f
                chipStartPadding = 14f
                chipEndPadding = 14f
                chipStrokeWidth = 0f
                chipBackgroundColor = ContextCompat.getColorStateList(this@ActivityReminders, R.color.chip_background_selector)
                setTextColor(ContextCompat.getColorStateList(this@ActivityReminders, R.color.chip_text_selector))
            }
            chipGroupPet.addView(petChip)
        }
    }

    private fun setupFilterListeners() {
        // Pet Filter Chips
        chipGroupPet.setOnCheckedStateChangeListener { group, checkedIds ->
            if (checkedIds.isEmpty()) {
                selectedPetFilter = "ALL"
            } else {
                val selectedChip = group.findViewById<Chip>(checkedIds[0])
                val text = selectedChip?.text?.toString() ?: "ALL"
                selectedPetFilter = if (text.equals("My Pets", ignoreCase = true) || text.equals("All Pets", ignoreCase = true)) "ALL" else text
            }
            applyFilters()
        }

        // Category Filter Chips
        chipGroupCategory.setOnCheckedStateChangeListener { _, checkedIds ->
            selectedCategoryFilter = when {
                checkedIds.contains(R.id.chipCatVet) -> ReminderCategory.VET_VISIT
                checkedIds.contains(R.id.chipCatBath) -> ReminderCategory.BATH
                checkedIds.contains(R.id.chipCatMed) -> ReminderCategory.MEDICATION
                checkedIds.contains(R.id.chipCatDiet) -> ReminderCategory.DIET
                else -> null
            }
            applyFilters()
        }
    }

    private fun getGroupedReminderDisplayList(): List<ReminderListItem> {
        val filtered = allReminders.filter { item ->
            val matchesPet = selectedPetFilter == "ALL" || item.petName.equals(selectedPetFilter, ignoreCase = true)
            val matchesCategory = selectedCategoryFilter == null || item.category == selectedCategoryFilter
            matchesPet && matchesCategory
        }

        val activeList = filtered.filter { !it.isCompleted }
        val completedList = filtered.filter { it.isCompleted }

        val resultList = mutableListOf<ReminderListItem>()

        // 1. Active / Uncompleted Reminders
        activeList.forEach { resultList.add(ReminderListItem.Item(it)) }

        // 2. Collapsible Completed Accordion Section Header
        if (completedList.isNotEmpty()) {
            resultList.add(
                ReminderListItem.Header(
                    title = "Completed (${completedList.size})",
                    isExpanded = isCompletedSectionExpanded,
                    isCompletedHeader = true
                )
            )

            // 3. Completed Items (Only shown if accordion is expanded)
            if (isCompletedSectionExpanded) {
                completedList.forEach { resultList.add(ReminderListItem.Item(it)) }
            }
        }

        return resultList
    }

    private fun applyFilters() {
        val displayList = getGroupedReminderDisplayList()
        adapter.updateDisplayList(displayList)

        if (displayList.isEmpty()) {
            rvReminders.visibility = View.GONE
            llEmptyState.visibility = View.VISIBLE
        } else {
            rvReminders.visibility = View.VISIBLE
            llEmptyState.visibility = View.GONE
        }
    }


}
