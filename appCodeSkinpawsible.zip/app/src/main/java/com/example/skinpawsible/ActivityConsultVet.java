package com.example.skinpawsible;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.button.MaterialButton;

public class ActivityConsultVet extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consult_vet);

        // Back Button Logic
        ImageButton btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // Start Consultation - Navigates to ActivityChat
        MaterialButton btnStartChat = findViewById(R.id.btnStartChat);
        if (btnStartChat != null) {
            btnStartChat.setOnClickListener(v -> {
                Intent intent = new Intent(ActivityConsultVet.this, ActivityChat.class);
                startActivity(intent);
            });
        }
    }
}