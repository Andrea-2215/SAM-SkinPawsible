package com.example.skinpawsible

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ReminderAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("EXTRA_TITLE") ?: "Care Reminder Alert!"
        val message = intent.getStringExtra("EXTRA_MESSAGE") ?: "You have an upcoming pet care reminder."

        // 1. Save to Cloud Firestore 'notifications' collection so it appears in the app
        val currentUser = FirebaseAuth.getInstance().currentUser
        if (currentUser != null) {
            val notifItem = NotificationItem(
                userId = currentUser.uid,
                title = title,
                message = message,
                timestamp = "Just now",
                createdAtMillis = System.currentTimeMillis(),
                type = NotificationType.REMINDER,
                targetScreen = "REMINDER",
                isRead = false
            )
            FirebaseFirestore.getInstance().collection("notifications")
                .document(notifItem.id)
                .set(notifItem.toMap())
        }

        // 2. Show Phone Status Bar Banner
        val targetIntent = Intent(context, ActivityNotifications::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        ReminderNotificationHelper.showSystemNotification(
            context = context,
            title = title,
            message = message,
            targetIntent = targetIntent
        )
    }
}
