package com.example.skinpawsible

data class ScanRecord(
    val id: String = "",
    val result: String = "Unknown Condition",
    val confidence: String = "0%", // Store percentage string e.g., "88%" or "65%"
    val date: String = "Recent",
    val imageUrl: String? = null
)