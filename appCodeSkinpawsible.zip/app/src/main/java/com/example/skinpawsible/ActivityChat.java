package com.example.skinpawsible;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ActivityChat extends BaseActivity {

    private EditText etMessage;
    private ImageButton btnSend;
    private ImageButton btnBack;
    private RecyclerView rvChatMessages;
    private View viewOnlineStatus;
    private TextView tvHeaderTitle;

    private ChatAdapter chatAdapter;
    private List<ChatMessage> messageList;

    // Firebase References
    private FirebaseFirestore db;
    private ListenerRegistration chatListener;
    private ListenerRegistration statusListener;

    private String currentUserId;
    private String vetId = "vet_456";
    private String chatId = "vet_consultation_session";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        // Bind Views
        btnBack = findViewById(R.id.btnBack);
        etMessage = findViewById(R.id.etMessage);
        btnSend = findViewById(R.id.btnSend);
        rvChatMessages = findViewById(R.id.rvChatMessages);
        viewOnlineStatus = findViewById(R.id.viewOnlineStatus);
        tvHeaderTitle = findViewById(R.id.tvHeaderTitle);

        // Firebase Auth Init
        db = FirebaseFirestore.getInstance();
        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        } else {
            currentUserId = "user_123";
        }

        // Setup RecyclerView (Fixed: single argument passed)
        messageList = new ArrayList<>();
        chatAdapter = new ChatAdapter(messageList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        rvChatMessages.setLayoutManager(layoutManager);
        rvChatMessages.setAdapter(chatAdapter);

        // Action Listeners
        btnBack.setOnClickListener(v -> finish());
        btnSend.setOnClickListener(v -> sendMessageToFirestore());

        // Setup Listeners
        listenForFirestoreMessages();
        listenForVetOnlineStatus();
    }

    private void sendMessageToFirestore() {
        String messageText = etMessage.getText().toString().trim();
        if (!messageText.isEmpty()) {
            etMessage.setText("");

            Map<String, Object> message = new HashMap<>();
            message.put("senderId", currentUserId);
            message.put("senderType", "user");
            message.put("text", messageText);
            message.put("timestamp", FieldValue.serverTimestamp());

            db.collection("chats")
                    .document(chatId)
                    .collection("messages")
                    .add(message)
                    .addOnFailureListener(e ->
                            Toast.makeText(ActivityChat.this, "Failed to send: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                    );
        }
    }

    private void listenForFirestoreMessages() {
        chatListener = db.collection("chats")
                .document(chatId)
                .collection("messages")
                .orderBy("timestamp", Query.Direction.ASCENDING)
                .addSnapshotListener((snapshots, error) -> {
                    if (error != null) {
                        Toast.makeText(ActivityChat.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (snapshots != null) {
                        for (DocumentChange dc : snapshots.getDocumentChanges()) {
                            if (dc.getType() == DocumentChange.Type.ADDED) {
                                ChatMessage message = dc.getDocument().toObject(ChatMessage.class);
                                messageList.add(message);
                                chatAdapter.notifyItemInserted(messageList.size() - 1);
                                rvChatMessages.smoothScrollToPosition(messageList.size() - 1);
                            }
                        }
                    }
                });
    }

    private void listenForVetOnlineStatus() {
        statusListener = db.collection("vets")
                .document(vetId)
                .addSnapshotListener((snapshot, error) -> {
                    if (error != null || snapshot == null || !snapshot.exists()) return;

                    Boolean isOnlineInDatabase = snapshot.getBoolean("isOnline");
                    String vetName = snapshot.getString("name");
                    if (vetName == null) vetName = "Partner Clinic / Vet";

                    // Check if current time is within 8:00 AM - 5:00 PM operating hours
                    boolean withinOperatingHours = isWithinOperatingHours(8, 17);

                    if (Boolean.TRUE.equals(isOnlineInDatabase) && withinOperatingHours) {
                        tvHeaderTitle.setText(vetName + " (Online)");
                        viewOnlineStatus.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#4CAF50"))); // Green
                    } else if (!withinOperatingHours) {
                        tvHeaderTitle.setText(vetName + " (Closed • 8 AM - 5 PM)");
                        viewOnlineStatus.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#9E9E9E"))); // Gray
                    } else {
                        tvHeaderTitle.setText(vetName + " (Offline)");
                        viewOnlineStatus.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#9E9E9E"))); // Gray
                    }
                });
    }

    // Helper method to evaluate clinic hours
    private boolean isWithinOperatingHours(int startHour, int endHour) {
        Calendar cal = Calendar.getInstance();
        int currentHour = cal.get(Calendar.HOUR_OF_DAY); // 24-hour format
        return currentHour >= startHour && currentHour < endHour;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (chatListener != null) chatListener.remove();
        if (statusListener != null) statusListener.remove();
    }
}