package com.example.skinpawsible

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ImageButton
import com.google.android.material.button.MaterialButton

class ActivityHelpSupport : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help_support)

        // Back button action
        val btnBack = findViewById<ImageButton>(R.id.btnBack)
        btnBack.setOnClickListener {
            finish()
        }

        // Navigate to ActivityConsultVet (which loads activity_consult_vet.xml)
        val btnStartVetChat = findViewById<MaterialButton>(R.id.btnStartVetChat)
        btnStartVetChat.setOnClickListener {
            val intent = Intent(this, ActivityConsultVet::class.java)
            startActivity(intent)
        }

        // Email Support button - Opens Gmail directly (with fallback)
        val btnEmailSupport = findViewById<MaterialButton>(R.id.btnEmailSupport)
        btnEmailSupport.setOnClickListener {
            val emailBody = """
                App Account Email: 
                
                Description of the issue:
                
                What I expected to happen:
                
                [Note: Please attach a screenshot if applicable]
            """.trimIndent()

            val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:skinpawsible@gmail.com")
                putExtra(Intent.EXTRA_SUBJECT, "SkinPawsible Support Request")
                putExtra(Intent.EXTRA_TEXT, emailBody)
                setPackage("com.google.android.gm") // Force Gmail app directly
            }

            try {
                startActivity(emailIntent)
            } catch (e: ActivityNotFoundException) {
                // Fallback: If Gmail app is not installed, clear package and show app chooser
                emailIntent.setPackage(null)
                startActivity(Intent.createChooser(emailIntent, "Send email via..."))
            }
        }

        // View Privacy Policy button
        val btnViewPrivacyPolicy = findViewById<MaterialButton>(R.id.btnViewPrivacyPolicy)
        btnViewPrivacyPolicy.setOnClickListener {
            val intent = Intent(this, ActivityPrivacyPolicy::class.java)
            startActivity(intent)
        }
    }
}