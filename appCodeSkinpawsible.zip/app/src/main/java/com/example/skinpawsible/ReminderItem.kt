package com.example.skinpawsible

import com.google.firebase.firestore.DocumentSnapshot
import java.util.UUID

enum class ReminderCategory(val displayName: String, val iconRes: Int, val bgColorHex: Long, val iconTintHex: Long) {
    BATH("Grooming & Bath", R.drawable.ic_shampoo, 0xFFEADCF8, 0xFF5B2E8F),
    MEDICATION("Medication", R.drawable.ic_first_aid, 0xFFFFEBEE, 0xFFE53935),
    VET_VISIT("Vet Appointment", R.drawable.ic_medical_history, 0xFFE3F2FD, 0xFF1E88E5),
    DIET("Diet & Supplements", R.drawable.ic_food_bowl, 0xFFFFF3E0, 0xFFFB8C00)
}

data class ReminderItem(
    val id: String = UUID.randomUUID().toString(),
    val userId: String = "",
    val petName: String = "",
    val title: String = "",
    val category: ReminderCategory = ReminderCategory.BATH,
    val dateTimeText: String = "",
    val repeatText: String = "",
    val notes: String = "",
    val createdBy: String = "User",
    val isVetPrescribed: Boolean = false,
    var isEnabled: Boolean = true,
    var isCompleted: Boolean = false
) {
    fun toMap(): HashMap<String, Any> {
        return hashMapOf(
            "id" to id,
            "userId" to userId,
            "petName" to petName,
            "title" to title,
            "category" to category.name,
            "dateTimeText" to dateTimeText,
            "repeatText" to repeatText,
            "notes" to notes,
            "createdBy" to createdBy,
            "isVetPrescribed" to isVetPrescribed,
            "isEnabled" to isEnabled,
            "isCompleted" to isCompleted
        )
    }

    companion object {
        fun fromDocument(doc: DocumentSnapshot): ReminderItem {
            val categoryStr = doc.getString("category") ?: "BATH"
            val categoryEnum = try {
                ReminderCategory.valueOf(categoryStr)
            } catch (e: Exception) {
                ReminderCategory.BATH
            }

            return ReminderItem(
                id = doc.getString("id") ?: doc.id,
                userId = doc.getString("userId") ?: "",
                petName = doc.getString("petName") ?: "",
                title = doc.getString("title") ?: "",
                category = categoryEnum,
                dateTimeText = doc.getString("dateTimeText") ?: "",
                repeatText = doc.getString("repeatText") ?: "",
                notes = doc.getString("notes") ?: "",
                createdBy = doc.getString("createdBy") ?: "User",
                isVetPrescribed = doc.getBoolean("isVetPrescribed") ?: false,
                isEnabled = doc.getBoolean("isEnabled") ?: true,
                isCompleted = doc.getBoolean("isCompleted") ?: false
            )
        }
    }
}
