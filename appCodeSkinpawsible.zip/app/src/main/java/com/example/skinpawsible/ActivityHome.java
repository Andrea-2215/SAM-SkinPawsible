package com.example.skinpawsible;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

public class ActivityHome extends BaseActivity {

    private TextView tvGreeting;
    private ImageButton btnNotification;
    private MaterialCardView cardCheckPet, cardConsultVet, cardMyPets, cardReminders;
    private FloatingActionButton fabScan;
    private BottomNavigationView bottomNavigation;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mAuth = FirebaseAuth.getInstance();
        // Safety check: if user is not logged in, go to MainActivity
        if (mAuth.getCurrentUser() == null) {
            startActivity(new Intent(ActivityHome.this, MainActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_home);
        db = FirebaseFirestore.getInstance();

        initViews();
        loadUserNameFromFirestore();
        setupClickListeners();
        setupBottomNavigation();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        overridePendingTransition(0, 0);
    }

    @Override
    protected void onPause() {
        super.onPause();
        overridePendingTransition(0, 0);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(0, 0);
    }

    private void initViews() {
        tvGreeting = findViewById(R.id.tvGreeting);
        btnNotification = findViewById(R.id.btnNotification);

        // 4 Main Grid Cards
        cardCheckPet = findViewById(R.id.cardCheckPet);
        cardConsultVet = findViewById(R.id.cardConsultVet);
        cardMyPets = findViewById(R.id.cardMyPets);
        cardReminders = findViewById(R.id.cardReminders);

        // Bottom Navigation Bar components
        fabScan = findViewById(R.id.fabScan);
        bottomNavigation = findViewById(R.id.bottomNavigation);
    }

    private void loadUserNameFromFirestore() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            String userId = currentUser.getUid();
            DocumentReference userRef = db.collection("users").document(userId);

            // Listen for changes to user profile in Firestore
            userRef.addSnapshotListener(new EventListener<DocumentSnapshot>() {
                @Override
                public void onEvent(DocumentSnapshot documentSnapshot, FirebaseFirestoreException error) {
                    if (error != null) {
                        tvGreeting.setText("Good day!");
                        return;
                    }

                    if (documentSnapshot != null && documentSnapshot.exists()) {
                        // 1. Primary: Try reading 'firstName'
                        String firstName = documentSnapshot.getString("firstName");

                        // 2. Fallback: If 'firstName' isn't set, try parsing 'fullName' or legacy 'name'
                        if (firstName == null || firstName.trim().isEmpty()) {
                            String fullName = documentSnapshot.getString("fullName");
                            if (fullName == null || fullName.trim().isEmpty()) {
                                fullName = documentSnapshot.getString("name");
                            }

                            if (fullName != null && !fullName.trim().isEmpty()) {
                                firstName = fullName.trim().split("\\s+")[0];
                            }
                        }

                        // 3. Render Greeting
                        if (firstName != null && !firstName.trim().isEmpty()) {
                            tvGreeting.setText("Good day, " + firstName.trim() + "!");
                        } else {
                            tvGreeting.setText("Good day!");
                        }
                    } else {
                        tvGreeting.setText("Good day!");
                    }
                }
            });
        }
    }

    private void setupClickListeners() {
        // Camera Actions
        if (cardCheckPet != null) cardCheckPet.setOnClickListener(v -> openScanner());
        if (fabScan != null) fabScan.setOnClickListener(v -> openScanner());

        // 4 Primary Grid Actions
        if (cardConsultVet != null) {
            cardConsultVet.setOnClickListener(v ->
                    startActivity(new Intent(ActivityHome.this, ActivityConsultVet.class))
            );
        }

        if (cardMyPets != null) {
            cardMyPets.setOnClickListener(v ->
                    startActivity(new Intent(ActivityHome.this, ActivityMyPets.class))
            );
        }

        if (cardReminders != null) {
            cardReminders.setOnClickListener(v ->
                    startActivity(new Intent(ActivityHome.this, ActivityReminders.class))
            );
        }

        // Header Notification Bell
        if (btnNotification != null) {
            btnNotification.setOnClickListener(v ->
                    startActivity(new Intent(ActivityHome.this, ActivityNotifications.class))
            );
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (bottomNavigation != null) {
            bottomNavigation.setSelectedItemId(R.id.nav_home);
        }
    }

    private void setupBottomNavigation() {
        if (bottomNavigation == null) return;

        // Navigation Item Clicks
        bottomNavigation.setOnItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_home) {
                return true;
            }

            Intent intent = null;
            if (id == R.id.nav_history) {
                intent = new Intent(ActivityHome.this, ActivityHistory.class);
            } else if (id == R.id.nav_manual) {
                intent = new Intent(ActivityHome.this, ActivityPetCareManual.class);
            } else if (id == R.id.nav_profile) {
                intent = new Intent(ActivityHome.this, ActivityProfile.class);
            }

            if (intent != null) {
                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
                overridePendingTransition(0, 0);
                return false; // Return false so the current activity's nav bar doesn't visually update
            }
            return false;
        });

        // Set active item
        bottomNavigation.setSelectedItemId(R.id.nav_home);
    }

    private void openScanner() {
        startActivity(new Intent(ActivityHome.this, ActivityPetScanner.class));
    }
}
