package com.example.skinpawsible

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import com.google.android.material.snackbar.Snackbar

open class BaseActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Enable edge-to-edge layout execution
        WindowCompat.setDecorFitsSystemWindows(window, false)
    }

    override fun setContentView(layoutResID: Int) {
        super.setContentView(layoutResID)
        applySystemBarInsets()
    }

    override fun setContentView(view: View?) {
        super.setContentView(view)
        applySystemBarInsets()
    }

    private fun applySystemBarInsets() {
        val rootView = findViewById<ViewGroup>(android.R.id.content) ?: return
        val mainLayout = if (rootView.childCount > 0) rootView.getChildAt(0) else rootView

        ViewCompat.setOnApplyWindowInsetsListener(mainLayout) { view, insets ->
            val statusBars = insets.getInsets(WindowInsetsCompat.Type.statusBars())
            val navigationBars = insets.getInsets(WindowInsetsCompat.Type.navigationBars())

            // Pad top to clear status bar icons
            view.updatePadding(top = statusBars.top)

            val bottomNavContainer = findViewById<View>(R.id.bottomNavInclude)

            if (bottomNavContainer != null) {
                // Apply Android nav bar height as MARGIN so container lifts up cleanly
                val params = bottomNavContainer.layoutParams as? ViewGroup.MarginLayoutParams
                if (params != null) {
                    params.bottomMargin = navigationBars.bottom
                    bottomNavContainer.layoutParams = params
                }
                view.updatePadding(bottom = 0)
            } else {
                // Screens without floating nav bar add padding directly to root layout
                view.updatePadding(bottom = navigationBars.bottom)
            }

            // CONSUME the insets so that child views (like BottomNavigationView) 
            // do not mistakenly add the system bar height as duplicate internal padding!
            WindowInsetsCompat.CONSUMED
        }

        ViewCompat.requestApplyInsets(mainLayout)
    }

    fun showError(message: String) {
        val rootView = findViewById<View>(android.R.id.content) ?: return
        val snackbar = Snackbar.make(rootView, message, Snackbar.LENGTH_LONG)
        snackbar.setBackgroundTint(Color.parseColor("#D32F2F"))
        snackbar.setTextColor(Color.WHITE)
        snackbar.show()
    }

    fun showErrorBanner(e: Throwable?) {
        showError(e?.localizedMessage ?: "An unexpected error occurred. Please try again.")
    }

    fun showSuccess(message: String) {
        val rootView = findViewById<View>(android.R.id.content) ?: return
        val snackbar = Snackbar.make(rootView, message, Snackbar.LENGTH_LONG)
        snackbar.setBackgroundTint(Color.parseColor("#2A1B4E"))
        snackbar.setTextColor(Color.WHITE)
        snackbar.show()
    }
}