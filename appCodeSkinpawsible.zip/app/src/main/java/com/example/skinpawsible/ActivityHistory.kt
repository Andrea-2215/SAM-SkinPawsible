package com.example.skinpawsible

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class ActivityHistory : BaseActivity() {

    private lateinit var rvHistory: RecyclerView
    private var bottomNavigation: BottomNavigationView? = null
    private var fabScan: FloatingActionButton? = null

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    private val scanRecords = mutableListOf<ScanRecord>()
    private lateinit var adapter: HistoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        rvHistory = findViewById(R.id.rvHistory)

        // Matching R.id.bottomNavInclude used in your XML files
        val layoutBottomNav = findViewById<View>(R.id.bottomNavInclude)
        if (layoutBottomNav != null) {
            bottomNavigation = layoutBottomNav.findViewById(R.id.bottomNavigation)
            fabScan = layoutBottomNav.findViewById(R.id.fabScan)
        } else {
            // Fallback direct bindings
            bottomNavigation = findViewById(R.id.bottomNavigation)
            fabScan = findViewById(R.id.fabScan)
        }

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        setupRecyclerView()

        fabScan?.setOnClickListener {
            startActivity(Intent(this, ActivityPetScanner::class.java))
        }

        setupBottomNavigation()
        loadScanHistoryFromFirestore()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        overridePendingTransition(0, 0)
    }

    override fun onPause() {
        super.onPause()
        overridePendingTransition(0, 0)
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(0, 0)
    }

    private fun setupRecyclerView() {
        adapter = HistoryAdapter(scanRecords) { selectedRecord ->
            val intent = Intent(this, ActivityScanResults::class.java).apply {
                putExtra("EXTRA_SCAN_ID", selectedRecord.id)
                putExtra("EXTRA_CONDITION", selectedRecord.result)
                putExtra("EXTRA_CONFIDENCE", selectedRecord.confidence)
                putExtra("EXTRA_DATE", selectedRecord.date)
                putExtra("EXTRA_IMAGE_URL", selectedRecord.imageUrl)
                putExtra("IS_FROM_HISTORY", true)
            }
            startActivity(intent)
        }
        rvHistory.layoutManager = LinearLayoutManager(this)
        rvHistory.adapter = adapter
    }

    private fun loadScanHistoryFromFirestore() {
        val userId = auth.currentUser?.uid ?: return

        db.collection("users")
            .document(userId)
            .collection("scans")
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .get()
            .addOnSuccessListener { documents ->
                scanRecords.clear()
                for (doc in documents) {
                    val record = ScanRecord(
                        id = doc.id,
                        result = doc.getString("result") ?: doc.getString("condition") ?: "Unknown Condition",
                        confidence = doc.getString("confidence") ?: "0%",
                        date = doc.getString("date") ?: "Recent",
                        imageUrl = doc.getString("imageUrl")
                    )
                    scanRecords.add(record)
                }
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener { error ->
                Toast.makeText(this, "Failed to load history: ${error.message}", Toast.LENGTH_SHORT).show()
            }
    }

    override fun onResume() {
        super.onResume()
        bottomNavigation?.selectedItemId = R.id.nav_history
    }

    private fun setupBottomNavigation() {
        val nav = bottomNavigation ?: return

        nav.setOnItemSelectedListener { item ->
            val id = item.itemId
            if (id == R.id.nav_history) return@setOnItemSelectedListener true

            var intent: Intent? = null
            when (id) {
                R.id.nav_home -> intent = Intent(this, ActivityHome::class.java)
                R.id.nav_manual -> intent = Intent(this, ActivityPetCareManual::class.java)
                R.id.nav_profile -> intent = Intent(this, ActivityProfile::class.java)
            }

            if (intent != null) {
                intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_NO_ANIMATION
                startActivity(intent)
                overridePendingTransition(0, 0)
                return@setOnItemSelectedListener false
            }
            false
        }

        nav.selectedItemId = R.id.nav_history
    }
}