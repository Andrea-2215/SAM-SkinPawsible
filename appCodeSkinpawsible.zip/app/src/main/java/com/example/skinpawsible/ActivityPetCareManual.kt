package com.example.skinpawsible

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.NestedScrollView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class ActivityPetCareManual : BaseActivity() {

    private lateinit var containerManuals: GridLayout
    private lateinit var etSearch: EditText
    private lateinit var btnClearSearch: ImageButton
    private lateinit var scrollViewDefault: NestedScrollView
    private lateinit var scrollViewSearchResults: NestedScrollView
    private lateinit var containerSearchResults: LinearLayout
    private lateinit var layoutNoResults: LinearLayout
    private lateinit var tvNoResultsText: TextView

    private val allSearchableSections by lazy { createSearchableSections() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pet_care_manual)

        containerManuals = findViewById(R.id.containerManuals)
        etSearch = findViewById(R.id.etSearch)
        btnClearSearch = findViewById(R.id.btnClearSearch)
        scrollViewDefault = findViewById(R.id.scrollViewDefault)
        scrollViewSearchResults = findViewById(R.id.scrollViewSearchResults)
        containerSearchResults = findViewById(R.id.containerSearchResults)
        layoutNoResults = findViewById(R.id.layoutNoResults)
        tvNoResultsText = findViewById(R.id.tvNoResultsText)

        btnClearSearch.setOnClickListener {
            etSearch.text.clear()
        }

        setupBottomNavigation()
        populateManualCards()
        setupSearchLogic()
    }

    override fun onResume() {
        super.onResume()
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNavigationView?.selectedItemId = R.id.nav_manual
    }

    private fun setupBottomNavigation() {
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        val fabScan = findViewById<FloatingActionButton>(R.id.fabScan)

        bottomNavigationView.selectedItemId = R.id.nav_manual

        bottomNavigationView.setOnItemSelectedListener { item ->
            val id = item.itemId
            if (id == R.id.nav_manual) return@setOnItemSelectedListener true

            var intent: Intent? = null
            when (id) {
                R.id.nav_home -> intent = Intent(this, ActivityHome::class.java)
                R.id.nav_history -> intent = Intent(this, ActivityHistory::class.java)
                R.id.nav_profile -> intent = Intent(this, ActivityProfile::class.java)
            }

            if (intent != null) {
                intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_NO_ANIMATION
                startActivity(intent)
                overridePendingTransition(0, 0)
                return@setOnItemSelectedListener false // Return false so the current activity's nav bar doesn't visually update
            }
            false
        }

        fabScan.setOnClickListener {
            // Start Scan Activity
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        overridePendingTransition(0, 0)
    }

    override fun onPause() {
        super.onPause()
        overridePendingTransition(0, 0)
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(0, 0)
    }

    private fun populateManualCards() {
        containerManuals.removeAllViews()

        val items = listOf(
            ManualItem("skin_care_basics", "Skin Care Basics", "Daily care tips", R.drawable.ic_paw, "#F4EEFA", "#5B2E8F"),
            ManualItem("common_diseases", "Common Skin Diseases", "Learn more", R.drawable.ic_allergies, "#FFF4E5", "#FF9800"),
            ManualItem("grooming_tips", "Grooming Tips", "Bathing, brushing and more", R.drawable.ic_grooming, "#F4EEFA", "#8B5FBF"),
            ManualItem("nutrition", "Nutrition", "Food for healthy skin", R.drawable.ic_nutrition, "#FFEBEB", "#FF4B4B"),
            ManualItem("preventive_care", "Preventive Care", "Vaccines, hygiene & prevention", R.drawable.ic_paw, "#F4EEFA", "#5B2E8F"),
            ManualItem("first_aid", "First Aid Guide", "What to do in emergencies", R.drawable.ic_first_aid, "#FFF4E5", "#FF9800")
        )

        for (item in items) {
            addManualCard(item)
        }
    }

    private fun addManualCard(item: ManualItem) {
        val inflater = LayoutInflater.from(this)
        val cardView = inflater.inflate(R.layout.item_manual_card, containerManuals, false)

        val ivIcon = cardView.findViewById<ImageView>(R.id.ivCardIcon)
        val tvTitle = cardView.findViewById<TextView>(R.id.tvCardTitle)
        val tvDesc = cardView.findViewById<TextView>(R.id.tvCardDesc)

        tvTitle.text = item.title
        tvDesc.text = item.desc
        ivIcon.setImageResource(item.iconResId)

        // Updated icon tint dynamically, using the parent view background directly since FrameLayout was removed
        ivIcon.imageTintList = ColorStateList.valueOf(Color.parseColor(item.tintColor))

        val params = cardView.layoutParams as GridLayout.LayoutParams
        params.width = 0
        params.height = GridLayout.LayoutParams.MATCH_PARENT
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
        params.rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
        cardView.layoutParams = params

        cardView.setOnClickListener {
            val intent = Intent(this, ActivityManualDetail::class.java)
            intent.putExtra("EXTRA_TOPIC_ID", item.topicId)
            startActivity(intent)
        }

        containerManuals.addView(cardView)
    }

    private fun setupSearchLogic() {
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                val query = s?.toString()?.trim() ?: ""
                if (query.isEmpty()) {
                    scrollViewDefault.visibility = View.VISIBLE
                    scrollViewSearchResults.visibility = View.GONE
                    btnClearSearch.visibility = View.GONE
                } else {
                    scrollViewDefault.visibility = View.GONE
                    scrollViewSearchResults.visibility = View.VISIBLE
                    btnClearSearch.visibility = View.VISIBLE
                    performSearch(query)
                }
            }
        })
    }

    private fun performSearch(query: String) {
        containerSearchResults.removeAllViews()
        val queryLower = query.lowercase()

        val matches = allSearchableSections.filter { item ->
            item.sectionTitle.lowercase().contains(queryLower) ||
                    item.parentTopicTitle.lowercase().contains(queryLower) ||
                    item.snippet.lowercase().contains(queryLower)
        }

        if (matches.isEmpty()) {
            containerSearchResults.visibility = View.GONE
            layoutNoResults.visibility = View.VISIBLE
            tvNoResultsText.text = "No results for \"$query\""
        } else {
            containerSearchResults.visibility = View.VISIBLE
            layoutNoResults.visibility = View.GONE

            val inflater = LayoutInflater.from(this)
            for (item in matches) {
                val cardView = inflater.inflate(R.layout.item_search_result, containerSearchResults, false)

                val tvSectionTitle = cardView.findViewById<TextView>(R.id.tvSectionTitle)
                val tvCategoryTitle = cardView.findViewById<TextView>(R.id.tvCategoryTitle)
                val tvSnippet = cardView.findViewById<TextView>(R.id.tvSnippet)
                val ivIcon = cardView.findViewById<ImageView>(R.id.ivIcon)
                val iconContainer = cardView.findViewById<View>(R.id.iconContainer)

                tvSectionTitle.text = item.sectionTitle
                tvCategoryTitle.text = "in ${item.parentTopicTitle}"
                tvSnippet.text = item.snippet
                ivIcon.setImageResource(item.iconResId)

                iconContainer.backgroundTintList = ColorStateList.valueOf(Color.parseColor(item.bgColor))
                ivIcon.imageTintList = ColorStateList.valueOf(Color.parseColor(item.tintColor))

                cardView.setOnClickListener {
                    val intent = Intent(this, ActivityManualDetail::class.java).apply {
                        putExtra("EXTRA_TOPIC_ID", item.parentTopicId)
                        putExtra("EXTRA_TARGET_SECTION", item.sectionTitle)
                    }
                    startActivity(intent)
                }

                containerSearchResults.addView(cardView)
            }
        }
    }

    private fun createSearchableSections(): List<SearchSectionItem> {
        return listOf(
            // Topic 1: Skin Care Basics
            SearchSectionItem("Understanding Pet Skin", "skin_care_basics", "Skin Care Basics", "Skin pH balance, acid mantle, dog and cat skin differences compared to human skin.", R.drawable.ic_paw, "#F4EEFA", "#5B2E8F"),
            SearchSectionItem("Daily Routine", "skin_care_basics", "Skin Care Basics", "Daily checks for lumps, bumps, scabs, redness, rashes, and moisture-prone areas.", R.drawable.ic_grooming, "#F4EEFA", "#5B2E8F"),
            SearchSectionItem("Brushing & Coat Checking", "skin_care_basics", "Skin Care Basics", "Distributing natural skin oils, removing dead hair, dirt, and preventing matting.", R.drawable.ic_paw, "#F4EEFA", "#5B2E8F"),
            SearchSectionItem("When to be Concerned", "skin_care_basics", "Skin Care Basics", "Excessive scratching, licking, fur loss (alopecia), foul odor, dandruff, red inflamed skin.", R.drawable.ic_first_aid, "#F4EEFA", "#5B2E8F"),

            // Topic 2: Common Skin Diseases
            SearchSectionItem("Flea Allergy Dermatitis (FAD)", "common_diseases", "Common Skin Diseases", "Allergic reaction to flea saliva proteins. Severe itching, red skin, tail base hair loss.", R.drawable.ic_bug, "#FFF4E5", "#FF9800"),
            SearchSectionItem("Ringworm (Dermatophytosis)", "common_diseases", "Common Skin Diseases", "Superficial fungal infection causing circular hairless patches with crusty borders. Zoonotic contagion.", R.drawable.ic_ringworm_badge, "#FFF4E5", "#FF9800"),
            SearchSectionItem("Mange (Sarcoptic vs. Demodectic)", "common_diseases", "Common Skin Diseases", "Microscopic skin mites. Sarcoptic scabies is intensely itchy and contagious. Demodex in hair follicles.", R.drawable.ic_microscope, "#FFF4E5", "#FF9800"),
            SearchSectionItem("Hot Spots (Acute Moist Dermatitis)", "common_diseases", "Common Skin Diseases", "Rapidly developing painful, moist, oozing skin inflammation caused by self-trauma from biting.", R.drawable.ic_flame, "#FFF4E5", "#FF9800"),
            SearchSectionItem("Yeast Dermatitis (Malassezia)", "common_diseases", "Common Skin Diseases", "Opportunistic yeast overgrowth causing greasy skin, hyperpigmentation, itching, and musty odor.", R.drawable.ic_yeast_badge, "#FFF4E5", "#FF9800"),
            SearchSectionItem("Bacterial Pyoderma", "common_diseases", "Common Skin Diseases", "Staphylococcus bacterial skin infection with pustules, papules, epidermal collarettes, and scaling.", R.drawable.ic_bacteria, "#FFF4E5", "#FF9800"),
            SearchSectionItem("Allergic Dermatitis (Atopy)", "common_diseases", "Common Skin Diseases", "Environmental allergies causing paw licking, face rubbing, groin redness, and ear infections.", R.drawable.ic_allergies, "#FFF4E5", "#FF9800"),

            // Topic 3: Grooming Tips
            SearchSectionItem("Bathing Basics & Frequency", "grooming_tips", "Grooming Tips", "Bathing every 4 to 8 weeks, pre-bath brushing for mats, lukewarm water, ear cotton balls.", R.drawable.ic_bathtub, "#F4EEFA", "#8B5FBF"),
            SearchSectionItem("Choosing the Right Shampoo", "grooming_tips", "Grooming Tips", "Species-formulated pH-balanced pet shampoos, colloidal oatmeal, medicated contact times, rinsing.", R.drawable.ic_shampoo, "#F4EEFA", "#8B5FBF"),
            SearchSectionItem("Coat Brushing & De-Shedding", "grooming_tips", "Grooming Tips", "Rubber curry brushes, undercoat rakes, slicker brushes for short, double, and long coats.", R.drawable.ic_brush, "#F4EEFA", "#8B5FBF"),
            SearchSectionItem("Ear Cleaning & Care", "grooming_tips", "Grooming Tips", "L-shaped ear canal hygiene, dedicated veterinary cleanser, avoiding Q-tips deep in ear.", R.drawable.ic_ear_care, "#F4EEFA", "#8B5FBF"),
            SearchSectionItem("Nail Trimming & Paw Care", "grooming_tips", "Grooming Tips", "Nail trimming every 3-4 weeks, locating the quick, styptic powder, paw pad hair maintenance.", R.drawable.ic_paw, "#F4EEFA", "#8B5FBF"),

            // Topic 4: Nutrition & Skin Health
            SearchSectionItem("Essential Fatty Acids (Omegas)", "nutrition", "Nutrition & Skin Health", "Omega-6 linoleic acid for skin barrier and Omega-3 EPA/DHA fish oil for anti-inflammatory itching.", R.drawable.ic_fish_omega, "#FFEBEB", "#FF4B4B"),
            SearchSectionItem("Protein & Keratin Synthesis", "nutrition", "Nutrition & Skin Health", "Keratin synthesis, methionine and cysteine sulfur amino acids, chicken, salmon, egg.", R.drawable.ic_protein, "#FFEBEB", "#FF4B4B"),
            SearchSectionItem("Hydration & Skin Elasticity", "nutrition", "Nutrition & Skin Health", "Cellular hydration, skin turgor, wet canned food, clean stainless steel or ceramic water bowls.", R.drawable.ic_water_drop, "#FFEBEB", "#FF4B4B"),
            SearchSectionItem("Adverse Food Reactions & Allergies", "nutrition", "Nutrition & Skin Health", "Dietary glycoproteins (beef, dairy, chicken, wheat), non-seasonal itching, otitis, soft stools.", R.drawable.ic_food_bowl, "#FFEBEB", "#FF4B4B"),
            SearchSectionItem("Veterinary Elimination Diet Trials", "nutrition", "Nutrition & Skin Health", "Novel protein or hydrolyzed prescription diet trial for 8 to 12 weeks, zero treats.", R.drawable.ic_microscope, "#FFEBEB", "#FF4B4B"),

            // Topic 5: Preventive Care
            SearchSectionItem("Year-Round Flea & Tick Control", "preventive_care", "Preventive Care", "Isoxazolines, spot-ons, collars, treating multi-pet households, vacuuming bedding.", R.drawable.ic_shield_check, "#F4EEFA", "#5B2E8F"),
            SearchSectionItem("Seasonal Skin Protection", "preventive_care", "Preventive Care", "Summer UV sunburn, hot pavement paw burns, winter dry air, road salt and de-icers.", R.drawable.ic_sun_snow, "#F4EEFA", "#5B2E8F"),
            SearchSectionItem("Environmental & Contact Hygiene", "preventive_care", "Preventive Care", "Hypoallergenic laundry detergents, dry floor disinfectant times, orthopedic washable beds.", R.drawable.ic_grooming, "#F4EEFA", "#5B2E8F"),
            SearchSectionItem("Routine Nose-to-Tail Inspections", "preventive_care", "Preventive Care", "Weekly tactile skin checks, recording seasonal flare-up dates for veterinary diagnosis.", R.drawable.ic_paw, "#F4EEFA", "#5B2E8F"),

            // Topic 6: First Aid Guide
            SearchSectionItem("Pet First Aid Kit Essentials", "first_aid", "First Aid Guide", "Sterile gauze, Vetwrap, chlorhexidine, saline wash, bandage scissors, tweezers, styptic powder.", R.drawable.ic_first_aid, "#FFF4E5", "#FF9800"),
            SearchSectionItem("Cuts, Scrapes & Puncture Wounds", "first_aid", "First Aid Guide", "Direct pressure bleeding control, saline wound flushing, cat bite puncture abscess warnings.", R.drawable.ic_bandage, "#FFF4E5", "#FF9800"),
            SearchSectionItem("Insect Stings & Localized Bites", "first_aid", "First Aid Guide", "Bee stinger scraping with credit card, cold compress, weight-based antihistamines.", R.drawable.ic_bug, "#FFF4E5", "#FF9800"),
            SearchSectionItem("Hives, Facial Swelling & Anaphylaxis", "first_aid", "First Aid Guide", "Urticaria, facial swelling, breathing difficulty, pale gums, immediate emergency vet transport.", R.drawable.ic_alert_triangle, "#FFF4E5", "#FF9800"),
            SearchSectionItem("Thermal Burns & Chemical Contact", "first_aid", "First Aid Guide", "10-minute cool water flush for burns, avoiding butter/ice, 15-minute chemical flushing.", R.drawable.ic_water_drop, "#FFF4E5", "#FF9800")
        )
    }

    data class ManualItem(
        val topicId: String,
        val title: String,
        val desc: String,
        val iconResId: Int,
        val bgColor: String,
        val tintColor: String
    )

    data class SearchSectionItem(
        val sectionTitle: String,
        val parentTopicId: String,
        val parentTopicTitle: String,
        val snippet: String,
        val iconResId: Int,
        val bgColor: String,
        val tintColor: String
    )
}