package com.example.skinpawsible;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;

import java.util.ArrayList;
import java.util.List;

public class ActivityMyPets extends BaseActivity {

    private ImageButton btnBack, btnAddPet;
    private RecyclerView rvPets;
    private LinearLayout layoutEmptyState;
    private SwipeRefreshLayout swipeRefresh;
    private PetAdapter petAdapter;
    private List<Pet> petList = new ArrayList<>();

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private ListenerRegistration petsListenerRegistration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_pets);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        initViews();
        setupRecyclerView();
        setupClickListeners();

        // Check if intent carries the trigger to automatically add a new pet
        checkIntentExtras(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        checkIntentExtras(intent);
    }

    private void checkIntentExtras(Intent intent) {
        if (intent != null && intent.getBooleanExtra("EXTRA_OPEN_ADD_PET", false)) {
            // Remove extra flag so it doesn't re-trigger on orientation change
            intent.removeExtra("EXTRA_OPEN_ADD_PET");
            startActivity(new Intent(this, ActivityAddPet.class));
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        listenToUserPets();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (petsListenerRegistration != null) {
            petsListenerRegistration.remove();
            petsListenerRegistration = null;
        }
    }

    private void initViews() {
        btnBack = findViewById(R.id.btnBack);
        btnAddPet = findViewById(R.id.btnAddPet);
        rvPets = findViewById(R.id.rvPets);
        layoutEmptyState = findViewById(R.id.layoutEmptyState);
        swipeRefresh = findViewById(R.id.swipeRefresh);
    }

    private void setupRecyclerView() {
        rvPets.setLayoutManager(new LinearLayoutManager(this));
        petAdapter = new PetAdapter(petList);
        rvPets.setAdapter(petAdapter);
    }

    private void setupClickListeners() {
        btnBack.setOnClickListener(v -> finish());

        btnAddPet.setOnClickListener(v -> {
            startActivity(new Intent(this, ActivityAddPet.class));
        });

        if (swipeRefresh != null) {
            swipeRefresh.setOnRefreshListener(this::listenToUserPets);
        }
    }

    private void listenToUserPets() {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user == null) {
            if (swipeRefresh != null) swipeRefresh.setRefreshing(false);
            return;
        }

        if (petsListenerRegistration != null) {
            petsListenerRegistration.remove();
        }

        petsListenerRegistration = db.collection("pets")
                .whereEqualTo("ownerId", user.getUid())
                .addSnapshotListener((queryDocumentSnapshots, e) -> {
                    if (swipeRefresh != null) {
                        swipeRefresh.setRefreshing(false);
                    }

                    if (e != null) {
                        Toast.makeText(this, "Failed to load pets: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        return;
                    }

                    petList.clear();
                    if (queryDocumentSnapshots != null && !queryDocumentSnapshots.isEmpty()) {
                        layoutEmptyState.setVisibility(View.GONE);
                        rvPets.setVisibility(View.VISIBLE);

                        for (DocumentSnapshot doc : queryDocumentSnapshots.getDocuments()) {
                            Pet pet = new Pet(
                                    doc.getId(),
                                    doc.getString("name"),
                                    doc.getString("breed"),
                                    doc.getString("age"),
                                    doc.getString("gender"),
                                    doc.getString("imageUrl")
                            );
                            petList.add(pet);
                        }
                    } else {
                        layoutEmptyState.setVisibility(View.VISIBLE);
                        rvPets.setVisibility(View.GONE);
                    }
                    petAdapter.notifyDataSetChanged();
                });
    }

    // Simple Pet Model
    public static class Pet {
        String id, name, breed, age, gender, imageUrl;
        public Pet(String id, String name, String breed, String age, String gender, String imageUrl) {
            this.id = id;
            this.name = name;
            this.breed = breed;
            this.age = age;
            this.gender = gender;
            this.imageUrl = imageUrl;
        }
    }

    // Inner Adapter Class
    private class PetAdapter extends RecyclerView.Adapter<PetAdapter.PetViewHolder> {
        private List<Pet> pets;

        public PetAdapter(List<Pet> pets) {
            this.pets = pets;
        }

        @NonNull
        @Override
        public PetViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_pet_card, parent, false);
            return new PetViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull PetViewHolder holder, int position) {
            Pet pet = pets.get(position);
            holder.tvName.setText(pet.name);
            holder.tvBreed.setText(pet.breed);

            if (pet.imageUrl != null && !pet.imageUrl.isEmpty()) {
                Glide.with(holder.itemView.getContext())
                        .load(pet.imageUrl)
                        .placeholder(R.drawable.skinpaw)
                        .error(R.drawable.skinpaw)
                        .into(holder.ivPet);
            } else {
                holder.ivPet.setImageResource(R.drawable.skinpaw);
            }

            holder.itemView.setOnClickListener(v -> {
                Intent intent = new Intent(ActivityMyPets.this, ActivityPetProfile.class);
                intent.putExtra("PET_ID", pet.id);
                startActivity(intent);
            });
        }

        @Override
        public int getItemCount() {
            return pets.size();
        }

        class PetViewHolder extends RecyclerView.ViewHolder {
            TextView tvName, tvBreed;
            ImageView ivPet;

            public PetViewHolder(@NonNull View itemView) {
                super(itemView);
                tvName = itemView.findViewById(R.id.tvPetItemName);
                tvBreed = itemView.findViewById(R.id.tvPetItemBreed);
                ivPet = itemView.findViewById(R.id.ivPetItemImage);
            }
        }
    }
}