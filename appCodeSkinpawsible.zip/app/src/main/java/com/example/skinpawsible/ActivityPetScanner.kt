package com.example.skinpawsible

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.ScaleGestureDetector
import android.widget.ImageButton
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import java.io.File
import java.util.UUID

class ActivityPetScanner : BaseActivity() {

    private lateinit var viewFinder: PreviewView
    private lateinit var btnBack: ImageButton
    private lateinit var btnFlash: FloatingActionButton
    private lateinit var btnCapture: FloatingActionButton
    private lateinit var btnGallery: FloatingActionButton

    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var isFlashOn = false

    // Pinch-to-Zoom Gesture Detector
    private lateinit var scaleGestureDetector: ScaleGestureDetector

    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()
    private val storage = FirebaseStorage.getInstance()

    // Permission Launcher
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            startCamera()
        } else {
            showError("Camera permission is required to scan.")
            finish()
        }
    }

    // Gallery Picker Launcher
    private val galleryLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val selectedImageUri: Uri? = result.data?.data
            if (selectedImageUri != null) {
                uploadAndSaveScan(selectedImageUri)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pet_scanner)

        initViews()
        setupListeners()
        setupPinchToZoom()

        if (allPermissionsGranted()) {
            startCamera()
        } else {
            requestPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun initViews() {
        viewFinder = findViewById(R.id.viewFinder)
        btnBack = findViewById(R.id.btnBack)
        btnFlash = findViewById(R.id.btnFlash)
        btnCapture = findViewById(R.id.btnCapture)
        btnGallery = findViewById(R.id.btnGallery)
    }

    private fun setupListeners() {
        btnBack.setOnClickListener { finish() }
        btnFlash.setOnClickListener { toggleFlash() }
        btnGallery.setOnClickListener { openGallery() }
        btnCapture.setOnClickListener { takePhoto() }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupPinchToZoom() {
        val listener = object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val currentCamera = camera ?: return false
                val currentZoomRatio = currentCamera.cameraInfo.zoomState.value?.zoomRatio ?: 1f
                val delta = detector.scaleFactor
                currentCamera.cameraControl.setZoomRatio(currentZoomRatio * delta)
                return true
            }
        }

        scaleGestureDetector = ScaleGestureDetector(this, listener)

        // Pass touch events to the scale detector safely
        viewFinder.setOnTouchListener { v, event ->
            scaleGestureDetector.onTouchEvent(event)
            v.performClick()
            true
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(viewFinder.surfaceProvider)
            }

            imageCapture = ImageCapture.Builder().build()
            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                cameraProvider.unbindAll()
                // Bind camera instance to track torch and zoom controls
                camera = cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageCapture)
            } catch (exc: Exception) {
                showError("Failed to start camera.")
            }

        }, ContextCompat.getMainExecutor(this))
    }

    private fun toggleFlash() {
        val currentCamera = camera
        if (currentCamera != null && currentCamera.cameraInfo.hasFlashUnit()) {
            isFlashOn = !isFlashOn
            currentCamera.cameraControl.enableTorch(isFlashOn)

            // Update icon color to reflect flashlight active state
            if (isFlashOn) {
                btnFlash.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#6750A4"))
            } else {
                btnFlash.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#80000000"))
            }
        } else {
            showError("Flashlight not available on this device")
        }
    }

    private fun takePhoto() {
        val imageCapture = imageCapture ?: return

        val photoFile = File(externalCacheDir, "${System.currentTimeMillis()}.jpg")
        val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

        imageCapture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    val savedUri = Uri.fromFile(photoFile)
                    uploadAndSaveScan(savedUri)
                }

                override fun onError(exception: ImageCaptureException) {
                    showError(exception.localizedMessage ?: "Photo capture failed.")
                }
            }
        )
    }

    private fun uploadAndSaveScan(imageUri: Uri) {
        val userId = auth.currentUser?.uid ?: return
        val scanId = UUID.randomUUID().toString()
        val storageRef = storage.reference.child("scan_images/$userId/$scanId.jpg")

        showSuccess("Uploading scan...")

        storageRef.putFile(imageUri)
            .continueWithTask { task ->
                if (!task.isSuccessful) {
                    task.exception?.let { throw it }
                }
                storageRef.downloadUrl
            }
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val downloadUri = task.result.toString()
                    saveScanToFirestore(scanId, userId, downloadUri)
                } else {
                    showError(task.exception?.localizedMessage ?: "Upload failed.")
                }
            }
    }

    private fun saveScanToFirestore(scanId: String, userId: String, imageUrl: String) {
        val scanData = hashMapOf(
            "scanId" to scanId,
            "userId" to userId,
            "imageUrl" to imageUrl,
            "detectedCondition" to "ringworm",
            "confidenceScore" to 0.88,
            "timestamp" to FieldValue.serverTimestamp()
        )

        db.collection("scans").document(scanId)
            .set(scanData)
            .addOnSuccessListener {
                showSuccess("Scan complete!")

                val intent = Intent(this, ActivityScanResults::class.java).apply {
                    putExtra("EXTRA_IMAGE_URI", imageUrl)
                    putExtra("EXTRA_CONDITION_KEY", "ringworm")
                    putExtra("EXTRA_CONFIDENCE_SCORE", 0.88f)
                    putExtra("EXTRA_PET_NAME", "Pet")
                }

                startActivity(intent)
                finish()
            }
            .addOnFailureListener { e ->
                showError(e.localizedMessage ?: "Failed to save scan record.")
            }
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        galleryLauncher.launch(intent)
    }

    private fun allPermissionsGranted() = ContextCompat.checkSelfPermission(
        baseContext, Manifest.permission.CAMERA
    ) == PackageManager.PERMISSION_GRANTED
}