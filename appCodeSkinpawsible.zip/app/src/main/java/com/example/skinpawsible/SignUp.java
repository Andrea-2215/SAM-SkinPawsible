package com.example.skinpawsible;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.ImageButton;
import android.widget.TextView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.checkbox.MaterialCheckBox;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;

public class SignUp extends BaseActivity {

    private ImageButton btnBack;
    private TextInputEditText etFirstName, etLastName, etEmail, etPhone, etPassword;
    private TextInputLayout tilFirstName, tilLastName, tilEmail, tilPhone, tilPassword;
    private MaterialCheckBox cbPrivacyPolicy;
    private MaterialButton btnRegister;
    private TextView tvAlreadyHaveAccount;

    // Firebase Instances
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // Initialize Firebase
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        initViews();

        // Back arrow click handler
        btnBack.setOnClickListener(v -> finish());

        // Register button listener
        btnRegister.setOnClickListener(v -> {
            if (validateInputs()) {
                performSignUp();
            }
        });

        // Navigate to ActivityLogin
        tvAlreadyHaveAccount.setOnClickListener(v -> {
            Intent intent = new Intent(SignUp.this, LoginForm.class);
            startActivity(intent);
            finish();
        });
    }

    private void initViews() {
        btnBack = findViewById(R.id.btnBack);

        etFirstName = findViewById(R.id.etFirstName);
        etLastName = findViewById(R.id.etLastName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        etPassword = findViewById(R.id.etPassword);

        tilFirstName = findViewById(R.id.tilFirstName);
        tilLastName = findViewById(R.id.tilLastName);
        tilEmail = findViewById(R.id.tilEmail);
        tilPhone = findViewById(R.id.tilPhone);
        tilPassword = findViewById(R.id.tilPassword);

        cbPrivacyPolicy = findViewById(R.id.cbPrivacyPolicy);
        btnRegister = findViewById(R.id.btnRegister);
        tvAlreadyHaveAccount = findViewById(R.id.tvAlreadyHaveAccount);

        // Standard Material Component method to ensure full tint contrast without lint warnings
        if (cbPrivacyPolicy != null) {
            cbPrivacyPolicy.setButtonTintList(ColorStateList.valueOf(Color.parseColor("#6750A4")));
        }
    }

    private boolean validateInputs() {
        boolean isValid = true;

        String firstName = etFirstName.getText() != null ? etFirstName.getText().toString().trim() : "";
        String lastName = etLastName.getText() != null ? etLastName.getText().toString().trim() : "";
        String email = etEmail.getText() != null ? etEmail.getText().toString().trim() : "";
        String phone = etPhone.getText() != null ? etPhone.getText().toString().trim() : "";
        String password = etPassword.getText() != null ? etPassword.getText().toString().trim() : "";

        // Reset previous inline errors
        tilFirstName.setError(null);
        tilLastName.setError(null);
        tilEmail.setError(null);
        tilPhone.setError(null);
        tilPassword.setError(null);

        // 1. First Name Validation
        if (firstName.isEmpty()) {
            tilFirstName.setError("Enter first name");
            isValid = false;
        }

        // 2. Last Name Validation
        if (lastName.isEmpty()) {
            tilLastName.setError("Enter last name");
            isValid = false;
        }

        // 3. Email Validation
        if (email.isEmpty()) {
            tilEmail.setError("Please enter your email");
            isValid = false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            tilEmail.setError("Please enter a valid email address");
            isValid = false;
        }

        // 4. Mobile Number Validation (Exactly 10 digits after +63)
        if (phone.isEmpty()) {
            tilPhone.setError("Enter mobile number");
            isValid = false;
        } else if (phone.length() != 10) {
            tilPhone.setError("Must be 10 digits (e.g. 9123456789)");
            isValid = false;
        }

        // 5. Password Validation
        if (password.isEmpty()) {
            tilPassword.setError("Please enter a password");
            isValid = false;
        } else if (password.length() < 6) {
            tilPassword.setError("Password must be at least 6 characters");
            isValid = false;
        } else if (!password.matches(".*\\d.*")) {
            tilPassword.setError("Password must include at least 1 number");
            isValid = false;
        }

        // 6. Privacy Policy Checkbox (Uses floating error Snackbar)
        if (!cbPrivacyPolicy.isChecked()) {
            showError("Please accept the Privacy Policy to proceed.");
            isValid = false;
        }

        return isValid;
    }

    private void performSignUp() {
        String firstName = etFirstName.getText() != null ? etFirstName.getText().toString().trim() : "";
        String lastName = etLastName.getText() != null ? etLastName.getText().toString().trim() : "";
        String email = etEmail.getText() != null ? etEmail.getText().toString().trim() : "";
        String rawPhone = etPhone.getText() != null ? etPhone.getText().toString().trim() : "";
        String password = etPassword.getText() != null ? etPassword.getText().toString().trim() : "";

        // Converts 10 digits ("9123456789") to standard "09123456789" format
        String formattedPhone = "0" + rawPhone;

        btnRegister.setEnabled(false);

        // 1. Register User in Firebase Authentication
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null) {
                            saveUserProfileToFirestore(user.getUid(), firstName, lastName, email, formattedPhone);
                        }
                    } else {
                        btnRegister.setEnabled(true);
                        String errorMsg = task.getException() != null ? task.getException().getMessage() : "Registration failed.";
                        showError("Error: " + errorMsg);
                    }
                });
    }

    private void saveUserProfileToFirestore(String userId, String firstName, String lastName, String email, String phone) {
        // 2. Build Updated User Document Map
        Map<String, Object> userProfile = new HashMap<>();
        userProfile.put("userId", userId);
        userProfile.put("firstName", firstName);
        userProfile.put("lastName", lastName);
        userProfile.put("fullName", firstName + " " + lastName);
        userProfile.put("email", email);
        userProfile.put("phone", phone);
        userProfile.put("role", "pet_owner");
        userProfile.put("createdAt", FieldValue.serverTimestamp());

        // 3. Save to Firestore under 'users' collection
        db.collection("users").document(userId)
                .set(userProfile)
                .addOnSuccessListener(aVoid -> {
                    showSuccess("Welcome to SkinPawsible, " + firstName + "!");

                    // Navigate to Home screen
                    Intent intent = new Intent(SignUp.this, ActivityHome.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e -> {
                    btnRegister.setEnabled(true);
                    showError("Failed to save profile: " + e.getMessage());
                });
    }
}