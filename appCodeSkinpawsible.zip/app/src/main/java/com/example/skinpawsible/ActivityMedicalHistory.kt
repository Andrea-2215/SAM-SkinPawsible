package com.example.skinpawsible

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class ActivityMedicalHistory : AppCompatActivity() {

    private lateinit var containerMedicalHistory: LinearLayout
    private lateinit var tvEmptyMessage: TextView
    private lateinit var btnBack: ImageButton

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_medical_history)

        containerMedicalHistory = findViewById(R.id.containerMedicalHistory)
        tvEmptyMessage = findViewById(R.id.tvEmptyMessage)
        btnBack = findViewById(R.id.btnBack)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        btnBack.setOnClickListener { finish() }

        loadMedicalHistory()
    }

    private fun loadMedicalHistory() {
        val user = auth.currentUser ?: return

        // For now, we fetch all medical records for the user's pets
        // In a more advanced version, we could filter by specific petId
        db.collection("medical_history")
            .whereEqualTo("userId", user.uid)
            .orderBy("date", Query.Direction.DESCENDING)
            .addSnapshotListener { value, error ->
                if (error != null) {
                    tvEmptyMessage.visibility = View.VISIBLE
                    return@addSnapshotListener
                }

                containerMedicalHistory.removeAllViews()

                if (value == null || value.isEmpty) {
                    tvEmptyMessage.visibility = View.VISIBLE
                } else {
                    tvEmptyMessage.visibility = View.GONE
                    for (doc in value.documents) {
                        addHistoryCard(
                            doc.getString("date") ?: "",
                            doc.getString("title") ?: "Checkup",
                            doc.getString("notes") ?: ""
                        )
                    }
                }
            }
    }

    private fun addHistoryCard(date: String, title: String, notes: String) {
        val inflater = LayoutInflater.from(this)
        val cardView = inflater.inflate(R.layout.item_medical_history, containerMedicalHistory, false)

        val tvRecordDate = cardView.findViewById<TextView>(R.id.tvRecordDate)
        val tvRecordTitle = cardView.findViewById<TextView>(R.id.tvRecordTitle)
        val tvRecordNotes = cardView.findViewById<TextView>(R.id.tvRecordNotes)

        tvRecordDate.text = date
        tvRecordTitle.text = title
        tvRecordNotes.text = notes

        containerMedicalHistory.addView(cardView)
    }
}