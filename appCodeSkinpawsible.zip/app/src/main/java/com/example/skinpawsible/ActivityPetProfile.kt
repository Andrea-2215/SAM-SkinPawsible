package com.example.skinpawsible

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.res.ResourcesCompat
import com.bumptech.glide.Glide
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.google.firebase.firestore.FirebaseFirestore

class ActivityPetProfile : AppCompatActivity() {

    private lateinit var btnBack: ImageButton
    private lateinit var ivPetImage: ImageView
    private lateinit var tvPetName: TextView
    private lateinit var tvPetBreedAge: TextView
    private lateinit var tvPetWeightDate: TextView
    private lateinit var tvAllergiesValue: TextView
    private lateinit var tvNotesValue: TextView
    private lateinit var ivPetGender: ImageView
    private lateinit var btnEditProfile: MaterialButton
    private lateinit var cardMedicalHistory: MaterialCardView
    private lateinit var cardAllergies: MaterialCardView
    private lateinit var cardNotes: MaterialCardView
    private lateinit var btnEditAllergies: ImageView
    private lateinit var btnEditNotes: ImageView

    private lateinit var db: FirebaseFirestore
    private var petId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pet_profile)

        db = FirebaseFirestore.getInstance()
        petId = intent.getStringExtra("PET_ID")

        initViews()
        setupClickListeners()
    }

    override fun onResume() {
        super.onResume()
        loadPetDetails()
    }

    private fun initViews() {
        btnBack = findViewById(R.id.btnBack)
        ivPetImage = findViewById(R.id.ivPetImage)
        tvPetName = findViewById(R.id.tvPetName)
        tvPetBreedAge = findViewById(R.id.tvPetBreedAge)
        tvPetWeightDate = findViewById(R.id.tvPetWeightDate)
        tvAllergiesValue = findViewById(R.id.tvAllergiesValue)
        tvNotesValue = findViewById(R.id.tvNotesValue)
        ivPetGender = findViewById(R.id.ivPetGender)
        btnEditProfile = findViewById(R.id.btnEditProfile)
        cardMedicalHistory = findViewById(R.id.cardMedicalHistory)
        cardAllergies = findViewById(R.id.cardAllergies)
        cardNotes = findViewById(R.id.cardNotes)
        btnEditAllergies = findViewById(R.id.btnEditAllergies)
        btnEditNotes = findViewById(R.id.btnEditNotes)
    }

    private fun setupClickListeners() {
        btnBack.setOnClickListener { finish() }

        btnEditProfile.setOnClickListener {
            val intent = Intent(this, ActivityEditPetProfile::class.java)
            intent.putExtra("PET_ID", petId)
            startActivity(intent)
        }

        cardMedicalHistory.setOnClickListener {
            val intent = Intent(this, ActivityMedicalHistory::class.java)
            intent.putExtra("PET_ID", petId)
            startActivity(intent)
        }

        val openAllergiesDialog = {
            val current = tvAllergiesValue.text.toString()
            showEditDialog("Allergies", current, false) { newValue ->
                updatePetField("allergies", newValue) {
                    tvAllergiesValue.text = if (newValue.isNotBlank()) newValue else "None"
                }
            }
        }

        cardAllergies.setOnClickListener { openAllergiesDialog() }
        btnEditAllergies.setOnClickListener { openAllergiesDialog() }

        val openNotesDialog = {
            val current = tvNotesValue.text.toString()
            showEditDialog("Notes", current, true) { newValue ->
                updatePetField("notes", newValue) {
                    tvNotesValue.text = if (newValue.isNotBlank()) newValue else "No notes added"
                }
            }
        }

        cardNotes.setOnClickListener { openNotesDialog() }
        btnEditNotes.setOnClickListener { openNotesDialog() }
    }

    private fun loadPetDetails() {
        val id = petId ?: return

        db.collection("pets").document(id).get()
            .addOnSuccessListener { doc ->
                if (doc != null && doc.exists()) {
                    val name = doc.getString("name") ?: ""
                    val breed = doc.getString("breed") ?: ""
                    val age = doc.getString("age") ?: ""
                    val gender = doc.getString("gender") ?: ""
                    val weight = doc.getString("weight") ?: ""
                    val allergies = doc.getString("allergies") ?: ""
                    val notes = doc.getString("notes") ?: ""
                    val imageUrl = doc.getString("imageUrl")

                    tvPetName.text = name
                    tvPetBreedAge.text = if (age.isNotBlank()) "$breed • $age years old" else breed

                    if (weight.isNotBlank()) {
                        tvPetWeightDate.text = if (weight.contains("kg", ignoreCase = true) || weight.contains("lbs", ignoreCase = true)) weight else "$weight kg"
                    } else {
                        tvPetWeightDate.text = "Weight: Not specified"
                    }

                    tvAllergiesValue.text = if (allergies.isNotBlank()) allergies else "None"
                    tvNotesValue.text = if (notes.isNotBlank()) notes else "No notes added"

                    if ("female".equals(gender, ignoreCase = true)) {
                        ivPetGender.setImageResource(R.drawable.ic_female)
                    } else {
                        ivPetGender.setImageResource(R.drawable.ic_male)
                    }

                    if (!imageUrl.isNullOrEmpty()) {
                        Glide.with(this)
                            .load(imageUrl)
                            .placeholder(R.drawable.skinpaw)
                            .error(R.drawable.skinpaw)
                            .into(ivPetImage)
                    } else {
                        ivPetImage.setImageResource(R.drawable.skinpaw)
                    }
                } else {
                    // Pet might have been deleted in Edit Profile screen
                    finish()
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error loading pet details", Toast.LENGTH_SHORT).show()
            }
    }

    private fun showEditDialog(title: String, currentValue: String, isMultiLine: Boolean, onSave: (String) -> Unit) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_edit_field, null)
        val tilInput = dialogView.findViewById<TextInputLayout>(R.id.tilInput)
        val etInput = dialogView.findViewById<TextInputEditText>(R.id.etInput)

        tilInput.hint = "Enter $title"

        val initial = if (currentValue == "None" || currentValue == "No notes added") "" else currentValue
        etInput.setText(initial)
        if (initial.isNotEmpty()) {
            try {
                etInput.setSelection(initial.length)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        if (isMultiLine) {
            etInput.isSingleLine = false
            etInput.minLines = 3
            etInput.gravity = Gravity.TOP
        } else {
            etInput.isSingleLine = true
        }

        AlertDialog.Builder(this)
            .setTitle("Update $title")
            .setView(dialogView)
            .setPositiveButton("Save") { dialog, _ ->
                val newText = etInput.text?.toString()?.trim() ?: ""
                onSave(newText)
                dialog.dismiss()
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun updatePetField(field: String, value: String, onSuccess: () -> Unit) {
        val id = petId ?: return
        db.collection("pets").document(id).update(field, value)
            .addOnSuccessListener {
                Toast.makeText(this, "Updated successfully", Toast.LENGTH_SHORT).show()
                onSuccess()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Failed to update: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}
