package com.example.skinpawsible

import android.app.ProgressDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.bumptech.glide.Glide
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.imageview.ShapeableImageView
import com.google.android.material.switchmaterial.SwitchMaterial
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import java.io.File

class ActivityProfile : BaseActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var storage: FirebaseStorage

    // Display views
    private lateinit var ivProfileAvatar: ImageView
    private lateinit var tvUserName: TextView
    private lateinit var tvUserEmail: TextView
    private lateinit var tvUserPhone: TextView
    private lateinit var btnEditProfile: TextView

    // Settings & Actions
    private lateinit var switchSmsAlerts: SwitchMaterial
    private lateinit var btnLogout: MaterialButton

    // Navigation
    private var bottomNavigation: BottomNavigationView? = null
    private var fabScan: FloatingActionButton? = null

    private var isProgrammaticChange = false
    private var selectedImageUri: Uri? = null
    private var tempCameraUri: Uri? = null
    private var dialogAvatarView: ShapeableImageView? = null

    private var firstName: String = ""
    private var lastName: String = ""

    // Image Pickers
    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            selectedImageUri = it
            dialogAvatarView?.let { imageView -> Glide.with(this).load(it).into(imageView) }
        }
    }

    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { success: Boolean ->
        if (success && tempCameraUri != null) {
            selectedImageUri = tempCameraUri
            dialogAvatarView?.let { imageView -> Glide.with(this).load(tempCameraUri).into(imageView) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()
        storage = FirebaseStorage.getInstance()

        initViews()
        loadUserProfile()
        setupListeners()
        setupBottomNavigation()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        overridePendingTransition(0, 0)
    }

    override fun onPause() {
        super.onPause()
        overridePendingTransition(0, 0)
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(0, 0)
    }

    private fun initViews() {
        ivProfileAvatar = findViewById(R.id.ivProfileAvatar)
        btnEditProfile = findViewById(R.id.btnEditProfile)

        tvUserName = findViewById(R.id.tvProfileName)
        tvUserEmail = findViewById(R.id.tvProfileEmail)
        tvUserPhone = findViewById(R.id.tvProfilePhone)

        switchSmsAlerts = findViewById(R.id.switchSmsAlerts)
        btnLogout = findViewById(R.id.btnLogout)

        bottomNavigation = findViewById(R.id.bottomNavigation)
        fabScan = findViewById(R.id.fabScan)
    }

    private fun setupListeners() {
        btnEditProfile.setOnClickListener {
            showEditProfileDialog()
        }

        // --- Privacy Policy Navigation ---
        findViewById<View>(R.id.btnPrivacyPolicy)?.setOnClickListener {
            val intent = Intent(this, ActivityPrivacyPolicy::class.java)
            startActivity(intent)
        }

        // --- Help & Support Navigation ---
        findViewById<View>(R.id.btnSupport)?.setOnClickListener {
            val intent = Intent(this, ActivityHelpSupport::class.java)
            startActivity(intent)
        }

        btnLogout.setOnClickListener {
            auth.signOut()
            Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, LoginForm::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

        switchSmsAlerts.setOnCheckedChangeListener { _, isChecked ->
            if (isProgrammaticChange) return@setOnCheckedChangeListener
            val userId = auth.currentUser?.uid ?: return@setOnCheckedChangeListener
            updateSmsPreference(userId, isChecked)
        }

        findViewById<View>(R.id.btnDeleteAccount)?.setOnClickListener {
            showDeleteConfirmation()
        }
    }

    private fun loadUserProfile() {
        val user = auth.currentUser ?: return
        db.collection("users").document(user.uid).get()
            .addOnSuccessListener { document ->
                if (isFinishing || isDestroyed) return@addOnSuccessListener
                if (document != null && document.exists()) {
                    firstName = document.getString("firstName") ?: ""
                    lastName = document.getString("lastName") ?: ""
                    val email = document.getString("email") ?: user.email ?: ""
                    val phone = document.getString("phone") ?: document.getString("phoneNumber") ?: ""
                    val smsEnabled = document.getBoolean("smsAlertsEnabled") ?: false
                    val profileImageUrl = document.getString("profileImageUrl")

                    tvUserName.text = if (firstName.isNotEmpty() || lastName.isNotEmpty()) "$firstName $lastName".trim() else "Pet Owner"
                    tvUserEmail.text = email
                    tvUserPhone.text = phone.ifEmpty { "No phone added" }

                    if (!profileImageUrl.isNullOrEmpty()) {
                        Glide.with(this).load(profileImageUrl).circleCrop().into(ivProfileAvatar)
                    } else {
                        ivProfileAvatar.setImageResource(R.drawable.ic_profile)
                    }

                    isProgrammaticChange = true
                    switchSmsAlerts.isChecked = smsEnabled
                    isProgrammaticChange = false
                }
            }
            .addOnFailureListener {
                if (!isFinishing && !isDestroyed) {
                    Toast.makeText(this, "Failed to load user profile", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun showEditProfileDialog() {
        val dialog = BottomSheetDialog(this)
        val view = layoutInflater.inflate(R.layout.dialog_edit_profile, findViewById(android.R.id.content), false)
        dialog.setContentView(view)

        selectedImageUri = null
        val ivEditAvatar = view.findViewById<ShapeableImageView>(R.id.ivEditAvatar)
        val etFirstName = view.findViewById<TextInputEditText>(R.id.etFirstName)
        val etLastName = view.findViewById<TextInputEditText>(R.id.etLastName)
        val etEmail = view.findViewById<TextInputEditText>(R.id.etEmailEdit)
        val etPhone = view.findViewById<TextInputEditText>(R.id.etPhoneEdit)
        val btnSave = view.findViewById<MaterialButton>(R.id.btnSaveProfile)

        dialogAvatarView = ivEditAvatar

        view.findViewById<View>(R.id.btnCancelEdit)?.setOnClickListener { dialog.dismiss() }

        etFirstName.setText(firstName)
        etLastName.setText(lastName)
        etEmail.setText(tvUserEmail.text)
        etEmail.isEnabled = false
        etPhone.setText(if (tvUserPhone.text == "No phone added") "" else tvUserPhone.text)

        // Load current pic into dialog
        db.collection("users").document(auth.currentUser?.uid ?: "").get().addOnSuccessListener { doc ->
            if (!isFinishing && !isDestroyed && doc.exists()) {
                val url = doc.getString("profileImageUrl")
                if (!url.isNullOrEmpty() && dialogAvatarView != null) {
                    Glide.with(this).load(url).into(ivEditAvatar)
                }
            }
        }

        view.findViewById<View>(R.id.layoutEditAvatar)?.setOnClickListener { showImageSourceOptions() }

        btnSave.setOnClickListener {
            val fName = etFirstName.text.toString().trim()
            val lName = etLastName.text.toString().trim()
            val phone = etPhone.text.toString().trim()

            if (fName.isEmpty() || lName.isEmpty()) {
                Toast.makeText(this, "First and last name are required", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            saveProfileChanges(fName, lName, phone, dialog)
        }
        dialog.show()
    }

    private fun showImageSourceOptions() {
        val options = arrayOf("Take Photo", "Choose from Gallery")
        MaterialAlertDialogBuilder(this)
            .setTitle("Select Profile Picture")
            .setItems(options) { d, which ->
                if (which == 0) openCamera() else galleryLauncher.launch("image/*")
                d.dismiss()
            }.show()
    }

    private fun openCamera() {
        val photoFile = File(cacheDir, "temp_avatar.jpg")
        tempCameraUri = FileProvider.getUriForFile(this, "${packageName}.provider", photoFile)
        tempCameraUri?.let { cameraLauncher.launch(it) }
    }

    @Suppress("DEPRECATION")
    private fun saveProfileChanges(fName: String, lName: String, phone: String, dialog: BottomSheetDialog) {
        val userId = auth.currentUser?.uid ?: return
        val progressDialog = ProgressDialog(this).apply {
            setMessage("Saving changes...")
            setCancelable(false)
            show()
        }

        val updates = mutableMapOf<String, Any>(
            "firstName" to fName,
            "lastName" to lName,
            "fullName" to "$fName $lName".trim(),
            "phone" to phone
        )

        if (selectedImageUri != null) {
            val ref = storage.reference.child("profile_images/$userId.jpg")
            ref.putFile(selectedImageUri!!).continueWithTask { task ->
                if (!task.isSuccessful) task.exception?.let { throw it }
                ref.downloadUrl
            }.addOnSuccessListener { uri ->
                updates["profileImageUrl"] = uri.toString()
                performFirestoreUpdate(userId, updates, dialog, progressDialog)
            }.addOnFailureListener { e ->
                progressDialog.dismiss()
                Toast.makeText(this, "Image upload failed: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        } else {
            performFirestoreUpdate(userId, updates, dialog, progressDialog)
        }
    }

    @Suppress("DEPRECATION")
    private fun performFirestoreUpdate(
        userId: String,
        updates: Map<String, Any>,
        dialog: BottomSheetDialog,
        progressDialog: ProgressDialog
    ) {
        db.collection("users").document(userId).update(updates)
            .addOnSuccessListener {
                progressDialog.dismiss()
                Toast.makeText(this, "Profile updated", Toast.LENGTH_SHORT).show()
                loadUserProfile()
                dialog.dismiss()
            }
            .addOnFailureListener { e ->
                progressDialog.dismiss()
                Toast.makeText(this, "Update failed: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun showDeleteConfirmation() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Delete Account?")
            .setMessage("This action is permanent and cannot be undone. All your profile data will be permanently removed.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                deleteUserAccount()
            }
            .show()
    }

    @Suppress("DEPRECATION")
    private fun deleteUserAccount() {
        val user = auth.currentUser ?: return
        val progressDialog = ProgressDialog(this).apply {
            setMessage("Deleting account...")
            setCancelable(false)
            show()
        }

        db.collection("users").document(user.uid).delete()
            .addOnSuccessListener {
                user.delete().addOnCompleteListener { task ->
                    progressDialog.dismiss()
                    if (task.isSuccessful) {
                        Toast.makeText(this, "Account deleted successfully", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this, LoginForm::class.java)
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        startActivity(intent)
                        finish()
                    } else {
                        Toast.makeText(this, "Failed to delete account: ${task.exception?.localizedMessage}", Toast.LENGTH_LONG).show()
                    }
                }
            }
            .addOnFailureListener { e ->
                progressDialog.dismiss()
                Toast.makeText(this, "Error deleting profile details: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun updateSmsPreference(userId: String, enabled: Boolean) {
        db.collection("users").document(userId).update("smsAlertsEnabled", enabled)
            .addOnFailureListener { revertSwitchState(!enabled) }
    }

    private fun revertSwitchState(state: Boolean) {
        isProgrammaticChange = true
        switchSmsAlerts.isChecked = state
        isProgrammaticChange = false
    }

    override fun onResume() {
        super.onResume()
        bottomNavigation?.selectedItemId = R.id.nav_profile
    }

    private fun setupBottomNavigation() {
        val nav = bottomNavigation ?: return
        nav.setOnItemSelectedListener { item ->
            val id = item.itemId
            if (id == R.id.nav_profile) return@setOnItemSelectedListener true
            val intent = when (id) {
                R.id.nav_home -> Intent(this, ActivityHome::class.java)
                R.id.nav_history -> Intent(this, ActivityHistory::class.java)
                R.id.nav_manual -> Intent(this, ActivityPetCareManual::class.java)
                else -> null
            }
            if (intent != null) {
                intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_NO_ANIMATION
                startActivity(intent)
                overridePendingTransition(0, 0)
                return@setOnItemSelectedListener false
            }
            false
        }
        nav.selectedItemId = R.id.nav_profile
        fabScan?.setOnClickListener { startActivity(Intent(this, ActivityPetScanner::class.java)) }
    }
}