package com.example.skinpawsible

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.RadioGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.google.android.material.button.MaterialButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import java.io.File
import java.io.FileOutputStream
import java.util.HashMap
import java.util.UUID

class ActivityAddPet : BaseActivity() {

    private lateinit var btnBack: ImageButton
    private lateinit var ivPetPhoto: ImageView
    private lateinit var btnChangePhoto: View
    private lateinit var etPetName: EditText
    private lateinit var etPetBreed: EditText
    private lateinit var etPetAge: EditText
    private lateinit var rgGender: RadioGroup
    private lateinit var btnSavePet: MaterialButton

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var storage: FirebaseStorage

    private var selectedImageUri: Uri? = null

    private val selectImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            selectedImageUri = uri
            Glide.with(this)
                .load(uri)
                .placeholder(R.drawable.skinpaw)
                .error(R.drawable.skinpaw)
                .into(ivPetPhoto)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_pet)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()
        storage = FirebaseStorage.getInstance()

        initViews()
        setupClickListeners()
    }

    private fun initViews() {
        btnBack = findViewById(R.id.btnBack)
        ivPetPhoto = findViewById(R.id.ivPetPhoto)
        btnChangePhoto = findViewById(R.id.btnChangePhoto)
        etPetName = findViewById(R.id.etPetName)
        etPetBreed = findViewById(R.id.etPetBreed)
        etPetAge = findViewById(R.id.etPetAge)
        rgGender = findViewById(R.id.rgGender)
        btnSavePet = findViewById(R.id.btnSavePet)
    }

    private fun setupClickListeners() {
        btnBack.setOnClickListener { finish() }

        val openGallery = {
            selectImageLauncher.launch("image/*")
        }

        ivPetPhoto.setOnClickListener { openGallery() }
        btnChangePhoto.setOnClickListener { openGallery() }

        btnSavePet.setOnClickListener {
            if (validateInputs()) {
                savePetToFirestore()
            }
        }
    }

    private fun validateInputs(): Boolean {
        if (etPetName.text.isNullOrBlank()) {
            Toast.makeText(this, "Please enter a pet name", Toast.LENGTH_SHORT).show()
            return false
        }
        if (etPetBreed.text.isNullOrBlank()) {
            Toast.makeText(this, "Please enter a breed", Toast.LENGTH_SHORT).show()
            return false
        }
        if (etPetAge.text.isNullOrBlank()) {
            Toast.makeText(this, "Please enter an age", Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }

    private fun saveImageLocally(uri: Uri, tempId: String): Uri? {
        return try {
            val inputStream = contentResolver.openInputStream(uri) ?: return null
            val photosDir = File(filesDir, "pet_photos")
            if (!photosDir.exists()) {
                photosDir.mkdirs()
            }
            val photoFile = File(photosDir, "pet_${tempId}.jpg")
            val outputStream = FileOutputStream(photoFile)
            inputStream.copyTo(outputStream)
            inputStream.close()
            outputStream.close()
            Uri.fromFile(photoFile)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun savePetToFirestore() {
        val user = auth.currentUser ?: return
        btnSavePet.isEnabled = false
        Toast.makeText(this, "Saving pet details...", Toast.LENGTH_SHORT).show()

        val tempId = UUID.randomUUID().toString()
        val imageUri = selectedImageUri

        if (imageUri != null) {
            val localUri = saveImageLocally(imageUri, tempId) ?: imageUri
            val imageRef = storage.reference.child("pet_images/${tempId}_${System.currentTimeMillis()}.jpg")
            imageRef.putFile(localUri)
                .addOnSuccessListener {
                    imageRef.downloadUrl.addOnSuccessListener { downloadUrl ->
                        insertPetDocument(user.uid, downloadUrl.toString())
                    }.addOnFailureListener {
                        insertPetDocument(user.uid, localUri.toString())
                    }
                }
                .addOnFailureListener {
                    insertPetDocument(user.uid, localUri.toString())
                }
        } else {
            insertPetDocument(user.uid, null)
        }
    }

    private fun insertPetDocument(userId: String, imageUrl: String?) {
        val petName = etPetName.text.toString().trim()
        val breed = etPetBreed.text.toString().trim()
        val age = etPetAge.text.toString().trim()

        val selectedGenderId = rgGender.checkedRadioButtonId
        val gender = if (selectedGenderId == R.id.rbMale) "male" else "female"

        val petData = HashMap<String, Any>()
        petData["ownerId"] = userId
        petData["name"] = petName
        petData["breed"] = breed
        petData["age"] = age
        petData["gender"] = gender
        if (!imageUrl.isNullOrEmpty()) {
            petData["imageUrl"] = imageUrl
        }
        petData["createdAt"] = FieldValue.serverTimestamp()

        db.collection("pets")
            .add(petData)
            .addOnSuccessListener {
                Toast.makeText(this, "$petName added successfully!", Toast.LENGTH_SHORT).show()
                finish()
            }
            .addOnFailureListener { e ->
                btnSavePet.isEnabled = true
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}
